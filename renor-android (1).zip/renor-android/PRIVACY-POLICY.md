# Privacy Policy: ReNor by Nor Gaxmer Builds

Last updated: [DATE] · Contact: [YOUR EMAIL]

ReNor helps you reduce screen time and stay focused. It has no servers, no account and no ads. Your data stays on your phone.

**Usage access.** ReNor reads Android's record of which apps you use and for how long, to show screen time, enforce
limits and block apps. This stays on your phone.

**ReNor protection (Full edition, Accessibility).** Used only to recognise Reels and Shorts screens in Instagram, YouTube,
Snapchat and Facebook, YouTube channel names during focus sessions (YouTube Study Mode), and ReNor's own settings and
uninstall screens while you have a lock running. ReNor doesn't store or send what's on your screen.

**Website blocker (VPN).** ReNor acts as your phone's DNS to block websites. Only website names are checked, on your
phone; allowed lookups are passed to a public DNS server (Cloudflare 1.1.1.1, or Google 8.8.8.8 as a backup). ReNor does
not see or route your other traffic, and keeps no browsing history.

**Device admin (optional).** Used only to stop ReNor being uninstalled while you choose to have uninstall protection on.

**Your data.** Limits, plans, focus history and settings are stored only in ReNor's private storage on your phone.
Delete everything from Settings > Reset, or by uninstalling. ReNor is for ages 13 and up.
