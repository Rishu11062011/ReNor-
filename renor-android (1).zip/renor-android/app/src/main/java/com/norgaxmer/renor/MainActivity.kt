package com.norgaxmer.renor

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    lateinit var store: Store
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    var tab = "home"
    val main = Handler(Looper.getMainLooper())

    /** Called every half second while a screen wants live updates (the focus timer). */
    var ticker: (() -> Unit)? = null
    private val tick = object : Runnable {
        override fun run() {
            ticker?.invoke()
            main.postDelayed(this, 500L)
        }
    }

    companion object {
        const val REQ_VPN = 41
        val TABS = listOf("home" to "Home", "focus" to "Focus", "block" to "Block", "insights" to "Insights", "plan" to "Plan")
        val ICONS = mapOf("home" to "\u2302", "focus" to "\u23F1", "block" to "\u26D4", "insights" to "\uD83D\uDCCA", "plan" to "\uD83D\uDCC5")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        Ui.load(store)
        GuardService.channels(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !store.bool("asked_notifications", false)) {
            store.putBool("asked_notifications", true)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
        }
        GuardService.start(this)
        Planner.scheduleAll(this)
        buildShell()
        show(intent?.getStringExtra("tab") ?: "home")
    }

    override fun onResume() {
        super.onResume()
        render()
        main.post(tick)
    }

    override fun onPause() {
        main.removeCallbacks(tick)
        super.onPause()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) {
            store.putBool("web_on", true)
            WebShield.start(this)
            toast("Website blocker is on")
            main.postDelayed({ render() }, 600L)
        }
    }

    // ================================================================== shell
    private fun buildShell() {
        window.statusBarColor = Ui.p.bg
        window.navigationBarColor = Ui.p.surface
        if (Build.VERSION.SDK_INT >= 30) {
            val light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (Ui.p.dark) 0 else light, light)
        }
        val root = Ui.col(this)
        root.setBackgroundColor(Ui.p.bg)
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        nav = Ui.row(this)
        nav.setBackgroundColor(Ui.p.surface)
        nav.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 8))
        root.addView(nav)
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 35) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            }
            insets
        }
        setContentView(root)
    }

    private fun buildNav() {
        nav.removeAllViews()
        for ((key, label) in TABS) {
            val selected = key == tab
            val item = Ui.col(this).apply { gravity = Gravity.CENTER }
            item.addView(Ui.text(this, ICONS[key] ?: "", 20f, if (selected) Ui.p.accent else Ui.p.muted).apply { gravity = Gravity.CENTER })
            item.addView(Ui.text(this, label, 12f, if (selected) Ui.p.accent else Ui.p.muted, selected).apply { gravity = Gravity.CENTER })
            item.setOnClickListener { show(key) }
            nav.addView(item, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    fun show(key: String) {
        tab = key
        render()
    }

    /** Rebuilds the current tab from the latest data. */
    fun render() {
        Ui.load(store)
        ticker = null
        buildNav()
        val page = when (tab) {
            "focus" -> focusScreen()
            "block" -> blockScreen()
            "insights" -> insightsScreen()
            "plan" -> planScreen()
            "settings" -> settingsScreen()
            else -> homeScreen()
        }
        content.removeAllViews()
        content.addView(page)
    }

    /** A scrolling page with standard padding. */
    fun page(build: (LinearLayout) -> Unit): View {
        val col = Ui.col(this)
        col.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 28))
        build(col)
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.addView(col)
        return scroll
    }

    /** "ReNor" heading with a screen name, and an optional settings gear. */
    fun header(col: LinearLayout, name: String, gear: Boolean = false) {
        val r = Ui.row(this)
        val texts = Ui.col(this)
        texts.addView(Ui.text(this, name, 26f, Ui.p.text, true))
        texts.addView(Ui.text(this, Brand.BYLINE, 12.5f, Ui.p.muted))
        r.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (gear) {
            val g = Ui.text(this, "\u2699\uFE0F", 22f).apply { setPadding(Ui.dp(this@MainActivity, 10), 0, 0, 0) }
            g.setOnClickListener { show("settings") }
            r.addView(g)
        }
        col.addView(r)
    }

    // ================================================================== permissions
    fun usageOk() = Usage.hasAccess(this)
    fun overlayOk() = Settings.canDrawOverlays(this)
    fun notificationsOk() = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    fun batteryOk() = (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    fun adminOk() = (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(ComponentName(this, AdminReceiver::class.java))

    /** Whether this is the Full edition (it includes ReNor protection). */
    fun fullEdition(): Boolean = try {
        packageManager.getServiceInfo(ComponentName(packageName, "com.norgaxmer.renor.ReNorAccessibility"), 0)
        true
    } catch (e: Exception) {
        false
    }

    fun protectionOk(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.contains("$packageName/")
    }

    fun openUsageAccess() = open(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    fun openOverlay() = open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    fun openBattery() = open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    fun openNotifications() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
        else open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }
    fun openProtection() {
        AlertDialog.Builder(this).setTitle("Turn on ReNor protection")
            .setMessage("1. Tap Open settings.\n2. Find ReNor protection (under Installed apps or Downloaded apps) and turn it on.\n\n" +
                "If it's greyed out: go to Settings > Apps > ReNor, tap \u22EE at the top right, choose \u201cAllow restricted settings\u201d, then try again.\n\n" +
                "ReNor only uses this to recognise Reels, Shorts and protected screens. Nothing leaves your phone.")
            .setPositiveButton("Open settings") { _, _ -> open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            .setNegativeButton("Later", null).show()
    }
    fun openAdmin() {
        val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this, AdminReceiver::class.java))
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Uninstall protection: ${Brand.APP} can't be removed until you switch this off, " +
                "which helps you keep your own commitments.")
        open(i)
    }
    fun startWebShield() {
        val consent = VpnService.prepare(this)
        if (consent != null) {
            try { startActivityForResult(consent, REQ_VPN) } catch (e: Exception) { toast("This phone doesn't allow the website blocker.") }
        } else {
            store.putBool("web_on", true)
            WebShield.start(this)
            toast("Website blocker is on")
        }
    }

    fun open(i: Intent): Boolean = try {
        startActivity(i)
        true
    } catch (e: Exception) {
        toast("This phone doesn't have that settings page.")
        false
    }

    // ================================================================== dialogs
    fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    fun choose(title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setItems(items.toTypedArray()) { _, which -> onPick(which) }.setNegativeButton("Cancel", null).show()
    }

    fun confirm(title: String, message: String, ok: String, onOk: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton(ok) { _, _ -> onOk() }.setNegativeButton("Cancel", null).show()
    }

    fun askText(title: String, hint: String, onDone: (String) -> Unit) {
        val field = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val wrap = LinearLayout(this).apply { setPadding(Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 20), 0); addView(field) }
        AlertDialog.Builder(this).setTitle(title).setView(wrap)
            .setPositiveButton("Save") { _, _ -> field.text.toString().trim().takeIf { it.isNotEmpty() }?.let(onDone) }
            .setNegativeButton("Cancel", null).show()
    }

    fun askNumber(title: String, current: Int, onDone: (Int) -> Unit) {
        val field = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(current.toString())
        }
        val wrap = LinearLayout(this).apply { setPadding(Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 20), 0); addView(field) }
        AlertDialog.Builder(this).setTitle(title).setView(wrap)
            .setPositiveButton("Save") { _, _ -> field.text.toString().trim().toIntOrNull()?.takeIf { it > 0 }?.let(onDone) }
            .setNegativeButton("Cancel", null).show()
    }

    fun pickTime(minute: Int, onPick: (Int) -> Unit) {
        TimePickerDialog(this, { _, h, m -> onPick(h * 60 + m) }, minute / 60, minute % 60, false).show()
    }

    /** Chooses an installed app (with a home-screen icon). */
    fun pickApp(title: String, onPick: (String, String) -> Unit) {
        val apps = Usage.apps(this)
        if (apps.isEmpty()) { toast("No apps found."); return }
        choose(title, apps.map { it.second }) { i -> onPick(apps[i].first, apps[i].second) }
    }

    /** "Commit once, no turning back": locks [kind] until the chosen time. */
    fun commit(kind: String, what: String, after: () -> Unit = {}) {
        val now = System.currentTimeMillis()
        val options = listOf("1 hour" to now + 3600_000L, "4 hours" to now + 4 * 3600_000L, "Until midnight" to Dates.endOfDay(),
            "24 hours" to now + 24 * 3600_000L, "7 days" to now + 7 * 24 * 3600_000L)
        choose("Lock $what for\u2026", options.map { it.first }) { i ->
            val until = options[i].second
            confirm("Commit to this?", "Your $what will be locked until ${Dates.until(until)}. You won't be able to change or switch them off before then, " +
                "not even from ${Brand.APP}. That's the point: it helps you keep your promise to yourself.", "Lock it") {
                store.lock(kind, until)
                toast("Locked until ${Dates.until(until)}")
                after()
                render()
            }
        }
    }

    fun lockNote(kind: String): String? = if (store.isLocked(kind)) "Locked until ${Dates.until(store.lockUntil(kind))}" else null

    fun note(col: LinearLayout, text: String, color: Int = Ui.p.muted) {
        Ui.add(col, Ui.text(this, text, 13f, color), 6)
    }

    fun spacer(): View = View(this)

    fun clickable(v: TextView, onTap: () -> Unit): TextView {
        v.setOnClickListener { onTap() }
        return v
    }
}
