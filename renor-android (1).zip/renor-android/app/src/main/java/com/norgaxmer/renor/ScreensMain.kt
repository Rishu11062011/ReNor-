package com.norgaxmer.renor

import android.app.AlarmManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import java.util.Calendar
import java.util.Locale

// ====================================================================== data helpers for the screens
/** Sample numbers are shown until Usage access is granted, or when you turn them on in Settings. */
fun MainActivity.demo(): Boolean = !usageOk() || store.bool("demo", false)

/** One day's screen time per app. Can be slow for past days: call from a background thread. */
fun MainActivity.dayUsage(day: Long): Map<String, Long> {
    if (demo()) return Sample.usage(day)
    val start = Dates.startOfDay(day)
    if (start == Dates.startOfDay() && System.currentTimeMillis() - UsageCache.refreshedAt < 60_000L && UsageCache.today.isNotEmpty()) return UsageCache.today
    return Usage.between(this, start, minOf(start + 24L * 3600_000L, System.currentTimeMillis()))
}

/** (productive, neutral, distracted) milliseconds. */
fun MainActivity.split(usage: Map<String, Long>): Triple<Long, Long, Long> {
    var p = 0L; var n = 0L; var d = 0L
    for ((pkg, ms) in usage) {
        when (Usage.tag(this, store, pkg)) {
            "productive" -> p += ms
            "distracting" -> d += ms
            else -> n += ms
        }
    }
    return Triple(p, n, d)
}

fun MainActivity.sessionsForInsights(): List<SessionRecord> =
    if (demo() && store.sessions().isEmpty()) Sample.sessions() else store.sessions()

fun MainActivity.label(pkg: String): String = if (demo()) Sample.label(pkg) else Usage.label(this, pkg)

/** Runs [work] in the background, then [show] on screen if the same tab is still open. */
fun <T> MainActivity.later(work: () -> T, show: (T) -> Unit) {
    val tabNow = tab
    Thread {
        val result = try { work() } catch (e: Exception) { null }
        if (result != null) main.post { if (tab == tabNow) show(result) }
    }.start()
}

val CATEGORY_COLORS = listOf("#5EEAD4", "#60A5FA", "#F472B6", "#FBBF24", "#A78BFA", "#34D399", "#F87171", "#94A3B8")

// ====================================================================== Home
fun MainActivity.homeScreen(): View = page { col ->
    val c = this
    header(col, Brand.APP, gear = true)
    Ui.add(col, Ui.text(c, Brand.TAGLINE, 14f, Ui.p.muted), 6)

    // Setup still needed?
    val missing = listOf(usageOk(), overlayOk(), notificationsOk()).count { !it }
    if (missing > 0) {
        val card = Ui.card(c)
        card.background = Ui.shape(c, Ui.p.surface, 18, Ui.p.warn)
        card.addView(Ui.text(c, "Finish setup: $missing step${if (missing > 1) "s" else ""} left", 16f, Ui.p.text, true))
        card.addView(Ui.text(c, "${Brand.APP} needs a few permissions to measure screen time and block apps.", 13.5f, Ui.p.muted))
        Ui.add(card, Ui.button(c, "Finish setup") { show("settings") }, 10)
        Ui.add(col, card, 14)
    }

    // Live focus session?
    val focus = FocusTimer.state(store)
    if (focus.running) {
        val card = Ui.card(c)
        card.background = Ui.shape(c, Ui.p.surface, 18, Ui.p.accent)
        val phase = when (focus.phase) { "short" -> "Short break"; "long" -> "Long break"; else -> "Focus session" }
        card.addView(Ui.text(c, "$phase in progress", 16f, Ui.p.text, true))
        val left = Ui.text(c, "", 14f, Ui.p.accent, true)
        card.addView(left)
        ticker = {
            val s = FocusTimer.state(store)
            left.text = if (!s.running) "Finished" else if (s.mode == "stopwatch") Dates.countdown(s.elapsed()) else Dates.countdown(s.remaining()) + " left"
        }
        Ui.add(card, Ui.button(c, "Open focus timer") { show("focus") }, 10)
        Ui.add(col, card, 14)
    }

    // Today vs your goal.
    val goalMin = store.int("goal_min", 180)
    val today = Ui.card(c)
    today.addView(Ui.text(c, "Today", 16f, Ui.p.text, true))
    val ring = RingView(c)
    ring.big = "\u2026"
    ring.small = "of ${Dates.duration(goalMin * 60_000L)} goal"
    today.addView(ring, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 190)))
    val splitBox = Ui.col(c)
    today.addView(splitBox)
    if (demo()) today.addView(Ui.text(c, "Sample data. Allow Usage access in Settings to see your own.", 12.5f, Ui.p.warn))
    Ui.add(col, today, 14)
    later({ dayUsage(System.currentTimeMillis()) }) { usage ->
        val total = usage.values.sum()
        val (p, n, d) = split(usage)
        ring.progress = total.toFloat() / (goalMin * 60_000f)
        ring.color = if (total > goalMin * 60_000L) Ui.p.danger else Ui.p.accent
        ring.big = Dates.duration(total)
        splitBox.removeAllViews()
        Ui.add(splitBox, Ui.splitBar(c, listOf(p.toFloat() to Ui.p.good, n.toFloat() to Ui.p.muted, d.toFloat() to Ui.p.danger)), 8)
        splitBox.addView(Ui.legend(c, Ui.p.good, "Productive", Dates.duration(p)))
        splitBox.addView(Ui.legend(c, Ui.p.danger, "Distracted", Dates.duration(d)))
        splitBox.addView(Ui.legend(c, Ui.p.muted, "Other", Dates.duration(n)))
        val top = usage.entries.sortedByDescending { it.value }.take(3)
        if (top.isNotEmpty()) {
            splitBox.addView(Ui.section(c, "Most used today"))
            for ((pkg, ms) in top) {
                val tagColor = when (Usage.tag(c, store, pkg)) { "productive" -> Ui.p.good; "distracting" -> Ui.p.danger; else -> Ui.p.text }
                splitBox.addView(Ui.line(c, label(pkg), Dates.duration(ms), tagColor))
            }
        }
    }

    // This week vs last week, against your reduction target.
    val target = store.int("target_pct", 25)
    val week = Ui.card(c)
    week.addView(Ui.text(c, "Weekly target: \u2212$target% screen time", 16f, Ui.p.text, true))
    val weekText = Ui.text(c, "Working it out\u2026", 14f, Ui.p.muted)
    week.addView(weekText)
    val weekBar = Ui.col(c)
    week.addView(weekBar)
    Ui.add(col, week, 12)
    later({
        var thisWeek = 0L
        var lastWeek = 0L
        for (i in 0 until 14) {
            val day = Dates.startOfDay() - i * 24L * 3600_000L
            val ms = dayUsage(day).values.sum()
            if (i < 7) thisWeek += ms else lastWeek += ms
        }
        Pair(thisWeek, lastWeek)
    }) { (thisWeek, lastWeek) ->
        if (lastWeek <= 0L) {
            weekText.text = "This week: ${Dates.duration(thisWeek)}. Next week ${Brand.APP} will compare it with this one."
        } else {
            val change = ((thisWeek - lastWeek) * 100.0 / lastWeek)
            val reduced = -change
            weekText.text = String.format(Locale.US, "Last 7 days: %s, %s %.0f%% vs the 7 days before.", Dates.duration(thisWeek),
                if (change <= 0) "down" else "up", Math.abs(change)) + if (reduced >= target) " Target reached \uD83C\uDF89" else ""
            weekText.setTextColor(if (reduced >= target) Ui.p.good else if (change <= 0) Ui.p.text else Ui.p.warn)
            weekBar.removeAllViews()
            val progress = (reduced / target).coerceIn(0.0, 1.0).toFloat()
            Ui.add(weekBar, Ui.splitBar(c, listOf(progress to Ui.p.good, (1f - progress) to Ui.p.surface2)), 8)
        }
    }

    // Streak and milestones.
    val streakCard = Ui.card(c)
    val streak = store.streak()
    val (reached, next) = Milestones.of(store.totalFocusMs())
    val focusHours = store.totalFocusMs() / 3600_000.0
    streakCard.addView(Ui.text(c, "\uD83D\uDD25 $streak-day focus streak", 18f, Ui.p.text, true))
    streakCard.addView(Ui.text(c, if (streak == 0) "Finish a focus session of 10 minutes or more today to start one." else "Focus for 10 minutes or more each day to keep it going.", 13.5f, Ui.p.muted))
    Ui.add(streakCard, Ui.line(c, "Total focus", String.format(Locale.US, "%.1f h", focusHours)), 8)
    streakCard.addView(Ui.line(c, "Next milestone", "$next h" + if (reached > 0) " (reached $reached h)" else ""))
    Ui.add(streakCard, Ui.splitBar(c, listOf((focusHours - reached).toFloat().coerceAtLeast(0f) to Ui.p.accent,
        (next - focusHours).toFloat().coerceAtLeast(0.01f) to Ui.p.surface2)), 6)
    Ui.add(col, streakCard, 12)

    // Quick start.
    col.addView(Ui.section(c, "Start focusing"))
    col.addView(Ui.strip(c, listOf(
        Ui.button(c, "Pomodoro") { quickStart("pomodoro") },
        Ui.button(c, "${FocusTimer.timerMin(store)} min", primary = false) { quickStart("timer") },
        Ui.button(c, "Stopwatch", primary = false) { quickStart("stopwatch") })))

    // Active commitments.
    val locks = listOf("limits" to "App limits", "web" to "Website blocker", "focus" to "Strict focus", "protection" to "Protection settings")
        .filter { store.isLocked(it.first) }
    if (locks.isNotEmpty()) {
        col.addView(Ui.section(c, "Active locks"))
        val card = Ui.card(c)
        for ((kind, name) in locks) card.addView(Ui.line(c, "\uD83D\uDD12 $name", "until " + Dates.until(store.lockUntil(kind)), Ui.p.warn))
        col.addView(card)
    }

    // Blocked today.
    val reels = store.count("reels")
    val sites = store.count("sites")
    if (reels + sites > 0) {
        col.addView(Ui.section(c, "Blocked today"))
        val card = Ui.card(c)
        if (reels > 0) card.addView(Ui.line(c, "Reels & Shorts stopped", "$reels"))
        if (sites > 0) card.addView(Ui.line(c, "Blocked website visits", "$sites"))
        col.addView(card)
    }

    // Next planned session.
    val now = System.currentTimeMillis()
    val nextPlan = store.plans().mapNotNull { p -> Planner.nextStart(p, now)?.let { Pair(p, it) } }.minByOrNull { it.second }
    if (nextPlan != null) {
        col.addView(Ui.section(c, "Next planned session"))
        val card = Ui.card(c)
        card.addView(Ui.text(c, nextPlan.first.title, 16f, Ui.p.text, true))
        card.addView(Ui.text(c, "${Dates.until(nextPlan.second)} \u00B7 ${nextPlan.first.minutes} min" + if (nextPlan.first.strict) " \u00B7 Strict" else "", 13.5f, Ui.p.muted))
        col.addView(card)
    }
}

fun MainActivity.quickStart(mode: String) {
    if (FocusTimer.state(store).running) { show("focus"); return }
    val strict = store.bool("strict_default", false) && mode != "stopwatch"
    val go = {
        FocusTimer.start(store, mode, strict, store.str("tag", "Study"))
        GuardService.start(this)
        show("focus")
    }
    if (strict) confirm("Start in Strict Mode?", "You won't be able to pause or stop this session, and only your allowed apps will open until it ends. Calls still work.", "Start") { go() }
    else go()
}

// ====================================================================== Settings
fun MainActivity.settingsScreen(): View = page { col ->
    val c = this
    val back = Ui.text(c, "\u2190 Home", 15f, Ui.p.accent, true)
    back.setOnClickListener { show("home") }
    col.addView(back)
    Ui.add(col, Ui.text(c, "Settings", 26f, Ui.p.text, true), 8)
    col.addView(Ui.text(c, Brand.BYLINE, 12.5f, Ui.p.muted))

    col.addView(Ui.section(c, "Setup"))
    val perms = Ui.card(c)
    fun perm(name: String, why: String, ok: Boolean, action: () -> Unit) {
        val r = Ui.row(c)
        val texts = Ui.col(c)
        texts.addView(Ui.text(c, (if (ok) "\u2705 " else "\u26A0\uFE0F ") + name, 15f, Ui.p.text, true))
        texts.addView(Ui.text(c, why, 12.5f, Ui.p.muted))
        r.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (!ok) r.addView(Ui.button(c, "Allow") { action() })
        r.setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 6))
        perms.addView(r)
    }
    perm("Usage access", "Measures screen time and sees which app is open.", usageOk()) { openUsageAccess() }
    perm("Display over other apps", "Shows the block screen over blocked apps.", overlayOk()) { openOverlay() }
    perm("Notifications", "Focus timer, phase changes and limit warnings.", notificationsOk()) { openNotifications() }
    perm("Unrestricted battery", "Stops Android from pausing ${Brand.APP}.", batteryOk()) { openBattery() }
    if (Build.VERSION.SDK_INT >= 31) {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        perm("Alarms & reminders", "Starts planned sessions exactly on time.", am.canScheduleExactAlarms()) {
            open(android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:$packageName")))
        }
    }
    if (fullEdition()) perm("ReNor protection", "Blocks Reels & Shorts, YouTube Study Mode and anti-bypass protection.", protectionOk()) { openProtection() }
    perm("Uninstall protection", "Optional: ${Brand.APP} can't be removed while this is on.", adminOk()) { openAdmin() }
    col.addView(perms)

    col.addView(Ui.section(c, "Goals"))
    val goals = Ui.card(c)
    val goalLine = Ui.line(c, "Daily screen time goal", Dates.duration(store.int("goal_min", 180) * 60_000L), Ui.p.accent)
    goalLine.setOnClickListener { askNumber("Daily screen time goal (minutes)", store.int("goal_min", 180)) { store.putInt("goal_min", it.coerceIn(15, 1440)); render() } }
    goals.addView(goalLine)
    val targetLine = Ui.line(c, "Weekly reduction target", "\u2212${store.int("target_pct", 25)}%", Ui.p.accent)
    targetLine.setOnClickListener {
        val options = listOf(10, 15, 20, 25, 30, 40)
        choose("Reduce screen time each week by", options.map { "$it%" }) { i -> store.putInt("target_pct", options[i]); render() }
    }
    goals.addView(targetLine)
    goals.addView(Ui.toggle(c, "Start focus in Strict Mode", "New sessions can't be paused or stopped early.", store.bool("strict_default", false)) {
        store.putBool("strict_default", it)
    })
    col.addView(goals)

    col.addView(Ui.section(c, "Theme"))
    val themes = Ui.row(c)
    for (t in Ui.THEMES) {
        val chip = Ui.chip(c, t.name, Ui.p.key == t.key) { store.putStr("theme", t.key); recreate() }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = Ui.dp(c, 8)
        themes.addView(chip, lp)
    }
    val scroller = android.widget.HorizontalScrollView(c)
    scroller.isHorizontalScrollBarEnabled = false
    scroller.addView(themes)
    col.addView(scroller)

    col.addView(Ui.section(c, "Data"))
    val data = Ui.card(c)
    data.addView(Ui.toggle(c, "Show sample data", "Fill the charts with realistic sample numbers, for trying ${Brand.APP} out.", store.bool("demo", false)) {
        store.putBool("demo", it)
    })
    val anyLock = store.anyLock()
    Ui.add(data, Ui.button(c, if (anyLock) "Reset locked while a commitment runs" else "Reset all ${Brand.APP} data", primary = false, enabled = !anyLock) {
        confirm("Reset everything?", "This deletes your limits, plans, history and streak from this phone.", "Reset") {
            store.clearAll()
            FocusTimer.stop(store, completed = false, force = true)
            WebShield.stop(c)
            recreate()
        }
    }, 8)
    col.addView(data)

    col.addView(Ui.section(c, "About"))
    val about = Ui.card(c)
    about.addView(Ui.text(c, Brand.APP, 22f, Ui.p.text, true))
    about.addView(Ui.text(c, "by ${Brand.STUDIO}", 14f, Ui.p.accent, true))
    Ui.add(about, Ui.text(c, Brand.TAGLINE, 14f, Ui.p.muted), 6)
    val version = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
    Ui.add(about, Ui.line(c, "Version", "$version (${if (fullEdition()) "Full" else "Lite"})"), 8)
    about.addView(Ui.text(c, "Everything stays on your phone: no account, no ads, no tracking.", 13f, Ui.p.muted))
    col.addView(about)
}

// ====================================================================== Insights
fun MainActivity.insightsScreen(): View = page { col ->
    val c = this
    header(col, "Insights")
    val mode = store.str("ui_insights", "week")
    Ui.add(col, Ui.strip(c, listOf(
        Ui.chip(c, "Today", mode == "day") { store.putStr("ui_insights", "day"); render() },
        Ui.chip(c, "This week", mode == "week") { store.putStr("ui_insights", "week"); render() })), 12)
    if (demo()) Ui.add(col, Ui.text(c, "Showing sample data. Allow Usage access in Settings to see your own.", 13f, Ui.p.warn), 8)
    val body = Ui.col(c)
    body.addView(Ui.text(c, "Working it out\u2026", 14f, Ui.p.muted).apply { setPadding(0, Ui.dp(c, 20), 0, 0) })
    col.addView(body)

    if (mode == "day") {
        later({ dayUsage(System.currentTimeMillis()) }) { usage -> body.removeAllViews(); dayInsights(body, usage) }
    } else {
        later({ (0 until 14).map { i -> dayUsage(Dates.startOfDay() - i * 24L * 3600_000L) } }) { days -> body.removeAllViews(); weekInsights(body, days) }
    }
}

private fun MainActivity.dayInsights(body: LinearLayout, usage: Map<String, Long>) {
    val c = this
    val total = usage.values.sum()
    val (p, n, d) = split(usage)
    val card = Ui.card(c)
    card.addView(Ui.text(c, "Screen time today", 14f, Ui.p.muted))
    card.addView(Ui.text(c, Dates.duration(total), 32f, Ui.p.text, true))
    Ui.add(card, Ui.splitBar(c, listOf(p.toFloat() to Ui.p.good, n.toFloat() to Ui.p.muted, d.toFloat() to Ui.p.danger)), 8)
    card.addView(Ui.legend(c, Ui.p.good, "Productive", Dates.duration(p)))
    card.addView(Ui.legend(c, Ui.p.danger, "Distracted", Dates.duration(d)))
    card.addView(Ui.legend(c, Ui.p.muted, "Other", Dates.duration(n)))
    Ui.add(body, card, 12)

    categories(body, usage)

    val focusToday = sessionsForInsights().filter { Dates.key(it.end) == Dates.key(System.currentTimeMillis()) }
    val f = Ui.card(c)
    f.addView(Ui.text(c, "Focus today", 16f, Ui.p.text, true))
    f.addView(Ui.line(c, "Sessions", "${focusToday.size}"))
    f.addView(Ui.line(c, "Focused time", Dates.duration(focusToday.sumOf { it.focusMs })))
    f.addView(Ui.line(c, "Reels & Shorts stopped", "${store.count("reels")}"))
    f.addView(Ui.line(c, "Blocked website visits", "${store.count("sites")}"))
    Ui.add(body, f, 12)

    body.addView(Ui.section(c, "Apps today (tap to re-tag)"))
    val apps = Ui.card(c)
    for ((pkg, ms) in usage.entries.sortedByDescending { it.value }.take(12)) {
        val tag = Usage.tag(c, store, pkg)
        val color = when (tag) { "productive" -> Ui.p.good; "distracting" -> Ui.p.danger; else -> Ui.p.muted }
        val row = Ui.line(c, label(pkg), Dates.duration(ms), color)
        row.setOnClickListener {
            choose("${label(pkg)} is\u2026", listOf("Productive", "Neutral", "Distracting")) { i ->
                val tags = store.map("app_tags")
                tags[pkg] = listOf("productive", "neutral", "distracting")[i]
                store.putMap("app_tags", tags)
                render()
            }
        }
        apps.addView(row)
    }
    if (usage.isEmpty()) apps.addView(Ui.text(c, "No screen time recorded yet today.", 14f, Ui.p.muted))
    body.addView(apps)
}

private fun MainActivity.categories(body: LinearLayout, usage: Map<String, Long>) {
    val c = this
    val byCategory = LinkedHashMap<String, Long>()
    for ((pkg, ms) in usage) {
        val cat = Usage.category(c, pkg)
        byCategory[cat] = (byCategory[cat] ?: 0L) + ms
    }
    val sorted = byCategory.entries.sortedByDescending { it.value }
    if (sorted.isEmpty()) return
    val card = Ui.card(c)
    card.addView(Ui.text(c, "Where your time goes", 16f, Ui.p.text, true))
    val slices = sorted.mapIndexed { i, e -> Pair(e.value.toFloat(), Color.parseColor(CATEGORY_COLORS[i % CATEGORY_COLORS.size])) }
    val donut = DonutView(c, slices, Dates.duration(usage.values.sum()))
    card.addView(donut, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 170)))
    sorted.forEachIndexed { i, e -> card.addView(Ui.legend(c, Color.parseColor(CATEGORY_COLORS[i % CATEGORY_COLORS.size]), e.key, Dates.duration(e.value))) }
    Ui.add(body, card, 12)
}

private fun MainActivity.weekInsights(body: LinearLayout, days: List<Map<String, Long>>) {
    val c = this
    val thisWeek = days.take(7)
    val lastWeek = days.drop(7)
    val totalThis = thisWeek.sumOf { it.values.sum() }
    val totalLast = lastWeek.sumOf { it.values.sum() }

    val card = Ui.card(c)
    card.addView(Ui.text(c, "Last 7 days", 14f, Ui.p.muted))
    card.addView(Ui.text(c, Dates.duration(totalThis), 32f, Ui.p.text, true))
    card.addView(Ui.text(c, "Average ${Dates.duration(totalThis / 7)} a day", 14f, Ui.p.muted))
    if (totalLast > 0) {
        val change = (totalThis - totalLast) * 100.0 / totalLast
        card.addView(Ui.text(c, String.format(Locale.US, "%s %.0f%% vs the week before", if (change <= 0) "\u25BC" else "\u25B2", Math.abs(change)), 15f,
            if (change <= 0) Ui.p.good else Ui.p.danger, true))
    }
    val bars = ArrayList<Bar>()
    for (i in 6 downTo 0) {
        val usage = thisWeek[i]
        val (p, n, d) = split(usage)
        val cal = Calendar.getInstance()
        cal.timeInMillis = Dates.startOfDay() - i * 24L * 3600_000L
        val name = Dates.DAY_NAMES.first { it.first == cal.get(Calendar.DAY_OF_WEEK) }.second
        bars.add(Bar(name, p / 60_000f, n / 60_000f, d / 60_000f, highlight = i == 0))
    }
    card.addView(BarChartView(c, bars), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 190)))
    card.addView(Ui.legend(c, Ui.p.good, "Productive", ""))
    card.addView(Ui.legend(c, Ui.p.danger, "Distracted", ""))
    card.addView(Ui.legend(c, Ui.p.muted, "Other", ""))
    Ui.add(body, card, 12)

    // Focus sessions this week.
    val sessions = sessionsForInsights().filter { it.end >= Dates.startOfDay() - 6 * 24L * 3600_000L }
    val f = Ui.card(c)
    f.addView(Ui.text(c, "Focus this week", 16f, Ui.p.text, true))
    val focusBars = ArrayList<Bar>()
    for (i in 6 downTo 0) {
        val dayKey = Dates.key(Dates.startOfDay() - i * 24L * 3600_000L)
        val minutes = sessions.filter { Dates.key(it.end) == dayKey }.sumOf { it.focusMs } / 60_000f
        val cal = Calendar.getInstance()
        cal.timeInMillis = Dates.startOfDay() - i * 24L * 3600_000L
        focusBars.add(Bar(Dates.DAY_NAMES.first { it.first == cal.get(Calendar.DAY_OF_WEEK) }.second, minutes, 0f, 0f, i == 0))
    }
    f.addView(BarChartView(c, focusBars, unit = "m"), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 160)))
    f.addView(Ui.line(c, "Sessions", "${sessions.size} (${sessions.count { it.completed }} completed)"))
    f.addView(Ui.line(c, "Focused time", Dates.duration(sessions.sumOf { it.focusMs })))
    sessions.maxByOrNull { it.focusMs }?.let { f.addView(Ui.line(c, "Longest session", Dates.duration(it.focusMs))) }
    Ui.add(body, f, 12)

    // What you focused on (tags).
    val byTag = sessions.groupBy { it.tag }.mapValues { e -> e.value.sumOf { it.focusMs } }.entries.sortedByDescending { it.value }
    if (byTag.isNotEmpty()) {
        val t = Ui.card(c)
        t.addView(Ui.text(c, "What you focused on", 16f, Ui.p.text, true))
        val slices = byTag.mapIndexed { i, e -> Pair(e.value.toFloat(), Color.parseColor(CATEGORY_COLORS[i % CATEGORY_COLORS.size])) }
        t.addView(DonutView(c, slices, Dates.duration(sessions.sumOf { it.focusMs })), LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(c, 160)))
        byTag.forEachIndexed { i, e -> t.addView(Ui.legend(c, Color.parseColor(CATEGORY_COLORS[i % CATEGORY_COLORS.size]), e.key, Dates.duration(e.value))) }
        Ui.add(body, t, 12)
    }

    val merged = HashMap<String, Long>()
    for (d in thisWeek) for ((k, v) in d) merged[k] = (merged[k] ?: 0L) + v
    categories(body, merged)
    body.addView(Ui.text(c, Brand.BYLINE, 12f, Ui.p.muted).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 16), 0, 0) })
}
