package com.norgaxmer.renor

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import java.util.Calendar

/** Why something is blocked, shown on the block screen. */
class Verdict(val block: Boolean, val title: String = "", val reason: String = "", val until: Long = 0L)

/** Decides whether an app may be used right now. Shared by the guard (all editions) and ReNor protection (Full). */
object Rules {
    /** Never blocked: calls and emergencies, the system, and ReNor itself. */
    private val ALWAYS = setOf(
        "android", "com.android.systemui", "com.android.phone", "com.android.server.telecom", "com.google.android.dialer",
        "com.android.dialer", "com.samsung.android.dialer", "com.samsung.android.incallui", "com.google.android.contacts",
        "com.android.contacts", "com.samsung.android.app.contacts", "com.android.emergency", "com.google.android.apps.safetyhub",
        "com.android.settings", "com.google.android.permissioncontroller", "com.android.permissioncontroller",
        "com.google.android.packageinstaller", "com.android.packageinstaller"
    )

    /** Allowed during strict focus unless you change the list: messages, clock and calculator. */
    val FOCUS_ALLOW_DEFAULT = setOf(
        "com.google.android.apps.messaging", "com.samsung.android.messaging", "com.google.android.deskclock", "com.sec.android.app.clockpackage",
        "com.google.android.calculator", "com.sec.android.app.popupcalculator"
    )

    /** Set by ReNor protection (Full edition) while it's switched on. */
    @Volatile var protectionOn = false

    private var ignoredCache: Set<String> = emptySet()
    private var ignoredAt = 0L

    fun focusAllowList(store: Store): Set<String> =
        if (store.bool("focus_allow_set", false)) store.set("focus_allow") else FOCUS_ALLOW_DEFAULT

    fun check(c: Context, store: Store, pkg: String): Verdict {
        val now = System.currentTimeMillis()
        if (now - ignoredAt > 60_000L) { ignoredCache = Usage.ignored(c); ignoredAt = now }
        if (pkg == c.packageName || pkg in ALWAYS || pkg in ignoredCache) return Verdict(false)
        val label = Usage.label(c, pkg)
        val tag = Usage.tag(c, store, pkg)

        // 1. Focus sessions: strict blocks everything outside your allow list; normal blocks distracting apps.
        val focus = FocusTimer.state(store)
        if (focus.running && !focus.paused && focus.phase == "focus") {
            val youtubeStudy = pkg == "com.google.android.youtube" && store.bool("yt_study", false) && protectionOn
            val phaseEnd = focus.phaseStart + focus.phaseLength
            if (focus.strict && pkg !in focusAllowList(store) && !youtubeStudy) {
                return Verdict(true, "Strict focus session", "$label is locked until this focus session ends. You chose Strict Mode, so it can't be ended early.",
                    if (focus.phaseLength > 0) phaseEnd else store.lockUntil("focus"))
            }
            if (!focus.strict && tag == "distracting" && !youtubeStudy) {
                return Verdict(true, "You're in a focus session", "$label is a distraction right now. Your break is coming.",
                    if (focus.phaseLength > 0) phaseEnd else 0L)
            }
        }

        // 2. Daily app limits.
        val limit = store.limits().firstOrNull { it.pkg == pkg }
        if (limit != null && UsageCache.msFor(pkg) >= limit.minutes * 60_000L) {
            return Verdict(true, "Daily limit reached", "You've used $label for ${Dates.duration(UsageCache.msFor(pkg))} today, your limit is ${limit.minutes} minutes." +
                (if (store.isLocked("limits")) " Your limits are locked by Strict Mode." else ""), Dates.endOfDay())
        }
        return Verdict(false)
    }
}

/** Today's screen time per app, refreshed by the guard every 30 seconds, plus live time in the app in front. */
object UsageCache {
    @Volatile var today: Map<String, Long> = emptyMap()
    @Volatile var refreshedAt = 0L
    @Volatile var current = ""
    @Volatile var currentSince = 0L

    fun msFor(pkg: String): Long {
        val base = today[pkg] ?: 0L
        return if (pkg == current && currentSince > 0) base + maxOf(0L, System.currentTimeMillis() - maxOf(currentSince, refreshedAt)) else base
    }
}

/** Keeps ReNor running: the focus timer, soundscapes, app limits, blocking and planned sessions. */
class GuardService : Service() {
    companion object {
        const val CH_ONGOING = "renor_ongoing"
        const val CH_ALERTS = "renor_alerts"
        private const val ONGOING_ID = 7001

        fun start(c: Context) {
            val i = Intent(c, GuardService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) { }
        }

        fun channels(c: Context) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH_ONGOING, "ReNor focus & protection", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows your focus timer and that ReNor is protecting your limits"
            })
            nm.createNotificationChannel(NotificationChannel(CH_ALERTS, "ReNor alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Focus phase changes, planned sessions and limit warnings"
            })
        }

        fun alert(c: Context, id: Int, title: String, text: String) {
            channels(c)
            val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(c, CH_ALERTS)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setSubText(Brand.BYLINE)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n) } catch (e: SecurityException) { }
        }
    }

    private lateinit var store: Store
    private lateinit var thread: HandlerThread
    private lateinit var worker: Handler
    private var lastNotified = 0L
    private var lastBlockPkg = ""
    private var lastBlockAt = 0L
    private var overlayWarned = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        channels(this)
        goForeground(buildOngoing())
        thread = HandlerThread("renor-guard").apply { start() }
        worker = Handler(thread.looper)
        worker.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastNotified = 0L
        return START_STICKY
    }

    override fun onDestroy() {
        worker.removeCallbacks(loop)
        thread.quitSafely()
        Soundscape.stop()
        super.onDestroy()
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ONGOING_ID, n)
    }

    private val loop: Runnable = object : Runnable {
        override fun run() {
            try { step() } catch (e: Exception) { }
            worker.postDelayed(this, 1000L)
        }
    }

    private fun step() {
        val now = System.currentTimeMillis()

        // Focus timer and its sounds.
        when (FocusTimer.tick(store, now)) {
            "short" -> alert(this, 7101, "Focus round done", "Take a short break. ${Brand.APP} will call you back.")
            "long" -> alert(this, 7101, "Great work: long break", "You've earned a longer break.")
            "focus" -> alert(this, 7101, "Back to focus", "Break's over. Let's go again.")
            "done" -> alert(this, 7101, "Session complete \uD83C\uDF89", "Focus session finished. Your streak is ${store.streak()} day(s).")
        }
        val focus = FocusTimer.state(store)
        val sound = store.str("sound", "off")
        if (focus.inFocus() && sound != "off") Soundscape.play(sound, store.int("volume", 50) / 100f) else Soundscape.stop()

        // Screen time, refreshed every 30 seconds.
        if (now - UsageCache.refreshedAt > 30_000L) {
            UsageCache.today = Usage.today(this)
            UsageCache.refreshedAt = now
            warnLimits()
        }

        // The app in front, and whether it's allowed.
        val fg = Usage.foreground(this)
        if (fg != null && fg != UsageCache.current) {
            UsageCache.current = fg
            UsageCache.currentSince = now
        }
        val current = UsageCache.current
        if (current.isNotEmpty()) {
            val verdict = Rules.check(this, store, current)
            if (verdict.block && (current != lastBlockPkg || now - lastBlockAt > 3000L)) {
                lastBlockPkg = current
                lastBlockAt = now
                showBlock(current, verdict)
            }
        }

        // Planned sessions that start themselves.
        Planner.startDue(this, store, now)

        // The ongoing notification: every second during a session, otherwise every half minute.
        if (focus.running || now - lastNotified > 30_000L) {
            lastNotified = now
            try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(ONGOING_ID, buildOngoing()) } catch (e: Exception) { }
        }
    }

    private fun showBlock(pkg: String, v: Verdict) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this) && !Rules.protectionOn) {
            if (!overlayWarned) {
                overlayWarned = true
                alert(this, 7102, "${Usage.label(this, pkg)} should be blocked", "Allow \u201cDisplay over other apps\u201d for ${Brand.APP} so it can show the block screen.")
            }
            return
        }
        val i = Intent(this, BlockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("pkg", pkg).putExtra("title", v.title).putExtra("reason", v.reason).putExtra("until", v.until)
        try { startActivity(i) } catch (e: Exception) { }
    }

    /** "5 minutes left on Instagram today", once a day per app. */
    private fun warnLimits() {
        val warned = store.set("warned_" + Dates.key(System.currentTimeMillis()))
        for (l in store.limits()) {
            val used = UsageCache.msFor(l.pkg)
            val left = l.minutes * 60_000L - used
            if (left in 1..5 * 60_000L && l.pkg !in warned) {
                warned.add(l.pkg)
                alert(this, 7200 + (l.pkg.hashCode() and 0xFF), "${Dates.duration(left)} left on ${l.label}", "You're close to your daily limit of ${l.minutes} minutes.")
            }
        }
        store.putSet("warned_" + Dates.key(System.currentTimeMillis()), warned)
    }

    private fun buildOngoing(): Notification {
        val focus = FocusTimer.state(store)
        val title: String
        val text: String
        if (focus.running) {
            val phase = when (focus.phase) { "short" -> "Short break"; "long" -> "Long break"; else -> "Focus" }
            val time = if (focus.mode == "stopwatch") Dates.countdown(focus.elapsed()) else Dates.countdown(focus.remaining()) + " left"
            title = "$phase \u00B7 $time" + (if (focus.paused) " (paused)" else "")
            text = (if (focus.mode == "pomodoro") "Round ${focus.round} of ${focus.rounds}. " else "") + (if (focus.strict) "Strict Mode is on." else "Stay with it.")
        } else {
            val total = UsageCache.today.values.sum()
            title = "${Brand.APP} is protecting your focus"
            text = "Screen time today: ${Dates.duration(total)}"
        }
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH_ONGOING)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setSubText(Brand.BYLINE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .build()
    }
}

/** Planned sessions: alarms at their start times, and starting the ones set to start themselves. */
object Planner {
    fun nextStart(plan: Plan, now: Long): Long? {
        val day = Calendar.getInstance()
        for (i in 0..8) {
            if (plan.occursOn(day)) {
                val start = Dates.startOfDay(day.timeInMillis) + plan.startMinute * 60_000L
                if (start > now) return start
            }
            day.add(Calendar.DAY_OF_YEAR, 1)
        }
        return null
    }

    fun scheduleAll(c: Context) {
        val store = Store(c)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        for (plan in store.plans()) {
            val pi = PendingIntent.getBroadcast(c, plan.id.hashCode(), Intent(c, PlanReceiver::class.java).putExtra("plan", plan.id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val at = nextStart(plan, now)
            if (at == null) { am.cancel(pi); continue }
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setWindow(AlarmManager.RTC_WAKEUP, at, 60_000L, pi)
            } catch (e: SecurityException) {
                am.setWindow(AlarmManager.RTC_WAKEUP, at, 60_000L, pi)
            }
        }
    }

    fun cancel(c: Context, plan: Plan) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(PendingIntent.getBroadcast(c, plan.id.hashCode(), Intent(c, PlanReceiver::class.java).putExtra("plan", plan.id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
    }

    /** Starts a plan set to start itself, if it's due now and nothing is running. */
    fun startDue(c: Context, store: Store, now: Long) {
        val minute = ((now - Dates.startOfDay(now)) / 60_000L).toInt()
        val today = Calendar.getInstance()
        val started = store.set("plans_started")
        for (plan in store.plans()) {
            if (!plan.autoStart || !plan.occursOn(today)) continue
            if (minute < plan.startMinute || minute > plan.startMinute + 2) continue
            val key = plan.id + "@" + Dates.key(now)
            if (key in started) continue
            started.add(key)
            store.putSet("plans_started", started)
            if (!FocusTimer.state(store).running) {
                FocusTimer.start(store, plan.mode, plan.strict, "Study", plan.id, plan.minutes)
                GuardService.alert(c, 7300, "Planned focus started: ${plan.title}", "${plan.minutes} minutes" + (if (plan.strict) ", Strict Mode" else "") + ". You've got this.")
            }
        }
    }
}

class PlanReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val store = Store(c)
        val plan = store.plans().firstOrNull { it.id == intent.getStringExtra("plan") }
        if (plan != null) {
            if (plan.autoStart) Planner.startDue(c, store, System.currentTimeMillis() + 1000L)
            else GuardService.alert(c, 7300, "Time to focus: ${plan.title}", "Your planned ${plan.minutes}-minute session starts now. Open ${Brand.APP} to begin.")
            GuardService.start(c)
        }
        Planner.scheduleAll(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        GuardService.start(c)
        Planner.scheduleAll(c)
        if (Store(c).bool("web_on", false)) WebShield.start(c)
    }
}

/** Uninstall protection: while this is on, ReNor has to be switched off as a device admin before it can be removed. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Turning this off lets ${Brand.APP} be uninstalled. Your commitment to yourself is still running. Are you sure?"
}
