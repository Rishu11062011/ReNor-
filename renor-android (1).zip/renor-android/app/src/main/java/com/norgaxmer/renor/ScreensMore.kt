package com.norgaxmer.renor

import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.util.Calendar
import java.util.UUID

// ====================================================================== Focus
fun MainActivity.focusScreen(): View = page { col ->
    val c = this
    header(col, "Focus")
    val s = FocusTimer.state(store)
    val mode = if (s.running) s.mode else store.str("mode", "pomodoro")

    Ui.add(col, Ui.strip(c, listOf("timer" to "Timer", "stopwatch" to "Stopwatch", "pomodoro" to "Pomodoro").map { (key, name) ->
        Ui.chip(c, name, mode == key) { if (!s.running) { store.putStr("mode", key); render() } }
    }), 12)

    // The live ring.
    val ring = RingView(c)
    val phaseText = Ui.text(c, "", 16f, Ui.p.text, true).apply { gravity = Gravity.CENTER }
    Ui.add(col, ring.also { it.minimumHeight = Ui.dp(c, 260) }, 16)
    (ring.layoutParams as LinearLayout.LayoutParams).height = Ui.dp(c, 260)
    col.addView(phaseText)
    var lastKey = "${s.running}-${s.phase}-${s.paused}-${s.round}"
    fun update() {
        val st = FocusTimer.state(store)
        val key = "${st.running}-${st.phase}-${st.paused}-${st.round}"
        if (key != lastKey) { lastKey = key; render(); return }
        if (!st.running) {
            val len = when (mode) {
                "timer" -> FocusTimer.timerMin(store) * 60_000L
                "pomodoro" -> FocusTimer.focusMin(store) * 60_000L
                else -> 0L
            }
            ring.big = if (mode == "stopwatch") "00:00" else Dates.countdown(len)
            ring.small = "Ready"
            ring.progress = 0f
            phaseText.text = when (mode) {
                "pomodoro" -> "${FocusTimer.rounds(store)} rounds of ${FocusTimer.focusMin(store)} min, with breaks"
                "timer" -> "One focus block of ${FocusTimer.timerMin(store)} minutes"
                else -> "Counts up until you stop"
            }
            return
        }
        ring.color = when (st.phase) { "focus" -> Ui.p.accent; else -> Ui.p.good }
        if (st.mode == "stopwatch") {
            ring.big = Dates.countdown(st.elapsed())
            ring.progress = (st.elapsed() % 3600_000L) / 3600_000f
        } else {
            ring.big = Dates.countdown(st.remaining())
            ring.progress = if (st.phaseLength > 0) st.elapsed().toFloat() / st.phaseLength else 0f
        }
        ring.small = if (st.paused) "Paused" else when (st.phase) { "short" -> "Short break"; "long" -> "Long break"; else -> "Focus" }
        phaseText.text = (if (st.mode == "pomodoro") "Round ${st.round} of ${st.rounds} \u00B7 " else "") + st.tag +
            (if (st.strict) " \u00B7 \uD83D\uDD12 Strict" else "")
    }
    update()
    ticker = { update() }

    // Controls.
    if (!s.running) {
        Ui.add(col, Ui.button(c, "Start focus") { startFocus(mode) }, 16)
    } else {
        val pause = Ui.button(c, if (s.paused) "Resume" else "Pause", primary = false, enabled = !s.strict) {
            if (FocusTimer.state(store).paused) FocusTimer.resume(store) else FocusTimer.pause(store)
            render()
        }
        val stop = Ui.button(c, if (s.strict) "Locked" else if (s.mode == "stopwatch") "Finish" else "Stop", primary = false, enabled = !s.strict) {
            val completed = s.mode == "stopwatch"
            confirm(if (completed) "Finish this session?" else "Stop early?", if (completed) "Your focused time will be saved." else
                "This session won't count as completed.", if (completed) "Finish" else "Stop") {
                FocusTimer.stop(store, completed)
                render()
            }
        }
        Ui.add(col, Ui.strip(c, listOf(pause, stop)), 16)
        if (s.phase != "focus") Ui.add(col, Ui.button(c, "Skip break", primary = false) { FocusTimer.skip(store); render() }, 8)
        if (s.strict) note(col, "Strict Mode: this session can't be paused or ended early. Only your allowed apps will open. Calls always work.", Ui.p.warn)
    }

    // Options (when nothing is running).
    if (!s.running) {
        col.addView(Ui.section(c, "Durations"))
        val d = Ui.card(c)
        fun setting(name: String, key: String, def: Int, unit: String, range: IntRange) {
            val l = Ui.line(c, name, "${store.int(key, def)} $unit", Ui.p.accent)
            l.setOnClickListener { askNumber(name, store.int(key, def)) { store.putInt(key, it.coerceIn(range.first, range.last)); render() } }
            d.addView(l)
        }
        when (mode) {
            "timer" -> setting("Focus length", "timer_min", 50, "min", 1..600)
            "pomodoro" -> {
                setting("Focus", "focus_min", 25, "min", 1..180)
                setting("Short break", "short_min", 5, "min", 1..60)
                setting("Long break", "long_min", 15, "min", 1..90)
                setting("Rounds per session", "rounds", 4, "", 1..16)
                setting("Long break after every", "cycles_before_long", 4, "rounds", 1..8)
            }
            else -> d.addView(Ui.text(c, "The stopwatch counts your focused time until you finish.", 14f, Ui.p.muted))
        }
        col.addView(d)

        col.addView(Ui.section(c, "Session"))
        val o = Ui.card(c)
        if (mode != "stopwatch") {
            o.addView(Ui.toggle(c, "Strict Mode", "Can't be paused or stopped early, and only allowed apps open until it ends.", store.bool("strict_default", false)) {
                store.putBool("strict_default", it)
            })
        }
        o.addView(Ui.text(c, "What are you focusing on?", 14f, Ui.p.muted).apply { setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 6)) })
        val tags = Ui.row(c)
        for (t in listOf("Study", "Work", "Reading", "Coding", "Revision", "Other")) {
            val chip = Ui.chip(c, t, store.str("tag", "Study") == t) { store.putStr("tag", t); render() }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = Ui.dp(c, 8)
            tags.addView(chip, lp)
        }
        val tagScroll = HorizontalScrollView(c)
        tagScroll.isHorizontalScrollBarEnabled = false
        tagScroll.addView(tags)
        o.addView(tagScroll)
        col.addView(o)
    }

    // Sound.
    col.addView(Ui.section(c, "Focus sounds"))
    val snd = Ui.card(c)
    val sounds = Ui.row(c)
    for ((key, name) in Soundscape.KINDS) {
        val chip = Ui.chip(c, name, store.str("sound", "off") == key) {
            store.putStr("sound", key)
            if (key == "off" || !FocusTimer.state(store).inFocus()) Soundscape.stop()
            render()
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.rightMargin = Ui.dp(c, 8)
        sounds.addView(chip, lp)
    }
    val soundScroll = HorizontalScrollView(c)
    soundScroll.isHorizontalScrollBarEnabled = false
    soundScroll.addView(sounds)
    snd.addView(soundScroll)
    val vol = store.int("volume", 50)
    Ui.add(snd, Ui.strip(c, listOf(
        Ui.button(c, "\u2212 Quieter", primary = false) { store.putInt("volume", (vol - 10).coerceAtLeast(10)); render() },
        Ui.text(c, "$vol%", 15f, Ui.p.text, true).apply { gravity = Gravity.CENTER },
        Ui.button(c, "+ Louder", primary = false) { store.putInt("volume", (vol + 10).coerceAtMost(100)); render() })), 10)
    snd.addView(Ui.text(c, "Plays only during focus. Steady sound is a popular way to mask distractions.", 12.5f, Ui.p.muted))
    col.addView(snd)

    // Allowed in Strict Mode.
    col.addView(Ui.section(c, "Allowed during Strict Mode"))
    val allowCard = Ui.card(c)
    val allow = Rules.focusAllowList(store)
    allowCard.addView(Ui.text(c, "Calls and emergency services always work. These apps can open too:", 13.5f, Ui.p.muted))
    for (pkg in allow) {
        val l = Ui.line(c, Usage.label(c, pkg), if (s.running && s.strict) "" else "Remove", Ui.p.danger)
        l.setOnClickListener {
            if (s.running && s.strict) return@setOnClickListener
            val set = allow.toMutableSet(); set.remove(pkg)
            store.putSet("focus_allow", set); store.putBool("focus_allow_set", true); render()
        }
        allowCard.addView(l)
    }
    Ui.add(allowCard, Ui.button(c, "Add an allowed app", primary = false, enabled = !(s.running && s.strict)) {
        pickApp("Allow during Strict Mode") { pkg, _ ->
            val set = allow.toMutableSet(); set.add(pkg)
            store.putSet("focus_allow", set); store.putBool("focus_allow_set", true); render()
        }
    }, 8)
    col.addView(allowCard)
}

fun MainActivity.startFocus(mode: String) {
    val strict = store.bool("strict_default", false) && mode != "stopwatch"
    val go = {
        FocusTimer.start(store, mode, strict, store.str("tag", "Study"))
        GuardService.start(this)
        render()
    }
    val needs = !usageOk() || !overlayOk()
    if (needs) toast("Tip: finish setup in Settings so ${Brand.APP} can block distractions.")
    if (strict) {
        val length = Dates.duration(FocusTimer.plannedLength(store, mode, null))
        confirm("Start a $length Strict session?", "You won't be able to pause or stop it, and only your allowed apps will open until it ends. Calls still work.", "Start") { go() }
    } else go()
}

// ====================================================================== Plan
fun MainActivity.planScreen(): View = page { col ->
    val c = this
    header(col, "Plan")

    val plans = store.plans()
    val done = store.set("plans_done")
    val streak = Ui.card(c)
    streak.addView(Ui.text(c, "\uD83D\uDD25 ${store.streak()}-day streak", 18f, Ui.p.text, true))
    var planned = 0
    var completed = 0
    for (i in 0 until 7) {
        val day = Calendar.getInstance()
        day.timeInMillis = Dates.startOfDay() - i * 24L * 3600_000L
        for (p in plans) if (p.occursOn(day)) {
            planned++
            if ("${p.id}@${Dates.key(day.timeInMillis)}" in done) completed++
        }
    }
    streak.addView(Ui.text(c, "Planned sessions done in the last 7 days: $completed of $planned", 14f, Ui.p.muted))
    if (planned > 0) Ui.add(streak, Ui.splitBar(c, listOf(completed.toFloat() to Ui.p.good, (planned - completed).toFloat().coerceAtLeast(0.01f) to Ui.p.surface2)), 8)
    Ui.add(col, streak, 12)

    // Week strip, starting today.
    val selected = store.long("ui_plan_day", Dates.startOfDay()).let { if (it < Dates.startOfDay()) Dates.startOfDay() else it }
    val strip = Ui.row(c)
    for (i in 0 until 7) {
        val dayStart = Dates.startOfDay() + i * 24L * 3600_000L
        val cal = Calendar.getInstance()
        cal.timeInMillis = dayStart
        val count = plans.count { it.occursOn(cal) }
        val isSel = dayStart == selected
        val cell = Ui.col(c).apply {
            gravity = Gravity.CENTER
            background = Ui.shape(c, if (isSel) Ui.p.accent else Ui.p.surface, 14, Ui.p.line)
            setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8))
        }
        val fg = if (isSel) Ui.p.onAccent else Ui.p.text
        cell.addView(Ui.text(c, Dates.DAY_NAMES.first { it.first == cal.get(Calendar.DAY_OF_WEEK) }.second, 12f, fg).apply { gravity = Gravity.CENTER })
        cell.addView(Ui.text(c, "${cal.get(Calendar.DAY_OF_MONTH)}", 16f, fg, true).apply { gravity = Gravity.CENTER })
        cell.addView(Ui.text(c, if (count > 0) "\u2022".repeat(minOf(count, 3)) else " ", 12f, if (isSel) Ui.p.onAccent else Ui.p.accent).apply { gravity = Gravity.CENTER })
        cell.setOnClickListener { store.putLong("ui_plan_day", dayStart); render() }
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        if (i > 0) lp.leftMargin = Ui.dp(c, 5)
        strip.addView(cell, lp)
    }
    Ui.add(col, strip, 14)

    // The selected day's sessions.
    val day = Calendar.getInstance()
    day.timeInMillis = selected
    val isToday = selected == Dates.startOfDay()
    col.addView(Ui.section(c, if (isToday) "Today" else java.text.SimpleDateFormat("EEEE d MMMM", java.util.Locale.ENGLISH).format(java.util.Date(selected))))
    val todays = plans.filter { it.occursOn(day) }.sortedBy { it.startMinute }
    if (todays.isEmpty()) note(col, "Nothing planned. Add a session below.")
    val nowMin = ((System.currentTimeMillis() - Dates.startOfDay()) / 60_000L).toInt()
    for (p in todays) {
        val card = Ui.card(c)
        card.addView(Ui.text(c, p.title, 16f, Ui.p.text, true))
        val repeat = if (p.days.isEmpty()) "Once" else if (p.days.size == 7) "Every day" else Dates.DAY_NAMES.filter { it.first in p.days }.joinToString(" ") { it.second }
        card.addView(Ui.text(c, "${p.timeText()} \u00B7 ${p.minutes} min \u00B7 ${if (p.mode == "timer") "Timer" else "Pomodoro"}" +
            (if (p.strict) " \u00B7 \uD83D\uDD12 Strict" else "") + (if (p.autoStart) " \u00B7 Auto-start" else "") + " \u00B7 $repeat", 13.5f, Ui.p.muted))
        val key = "${p.id}@${Dates.key(selected)}"
        val status = when {
            key in done -> "\u2705 Done"
            isToday && nowMin > p.startMinute + p.minutes -> "Missed"
            selected < Dates.startOfDay() -> "Missed"
            else -> "Upcoming"
        }
        card.addView(Ui.text(c, status, 13.5f, if (key in done) Ui.p.good else if (status == "Missed") Ui.p.warn else Ui.p.accent, true))
        val buttons = ArrayList<View>()
        if (isToday && key !in done) buttons.add(Ui.button(c, "Start now", enabled = !FocusTimer.state(store).running) {
            val go = {
                FocusTimer.start(store, p.mode, p.strict, store.str("tag", "Study"), p.id, p.minutes)
                GuardService.start(this)
                show("focus")
            }
            if (p.strict) confirm("Start in Strict Mode?", "This ${p.minutes}-minute session can't be paused or stopped early.", "Start") { go() } else go()
        })
        buttons.add(Ui.button(c, "Delete", primary = false) {
            confirm("Delete \u201c${p.title}\u201d?", "This removes it from every day it repeats.", "Delete") {
                Planner.cancel(this, p)
                store.savePlans(store.plans().filter { it.id != p.id })
                render()
            }
        })
        Ui.add(card, Ui.strip(c, buttons), 10)
        Ui.add(col, card, 10)
    }
    Ui.add(col, Ui.button(c, "+ Plan a focus session") { addPlan(selected) }, 16)
    note(col, "Planned sessions remind you when they start. Choose Auto-start to begin them by themselves.")
}

/** Title, time, length, repeat, mode, Strict and Auto-start, one question at a time. */
fun MainActivity.addPlan(day: Long) {
    askText("What will you focus on?", "e.g. Physics revision") { title ->
        pickTime(18 * 60) { start ->
            val lengths = listOf(25, 50, 90, 120)
            choose("How long?", lengths.map { "$it minutes" } + "Custom\u2026") { li ->
                val afterLength = { minutes: Int ->
                    val repeats = listOf("Only this day", "Every day", "Weekdays (Mon\u2013Fri)", "Weekends")
                    choose("Repeat", repeats) { ri ->
                        val days: Set<Int> = when (ri) {
                            1 -> Dates.DAY_NAMES.map { it.first }.toSet()
                            2 -> setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)
                            3 -> setOf(Calendar.SATURDAY, Calendar.SUNDAY)
                            else -> emptySet()
                        }
                        choose("Style", listOf("Pomodoro (focus + breaks)", "One timer block")) { mi ->
                            choose("Strict Mode?", listOf("Strict: can't stop early", "Normal")) { si ->
                                choose("Start it by itself?", listOf("Yes, auto-start", "No, just remind me")) { ai ->
                                    val plan = Plan(UUID.randomUUID().toString().take(8), title, start, minutes, days, Dates.key(day),
                                        if (mi == 0) "pomodoro" else "timer", si == 0, ai == 0)
                                    val all = store.plans()
                                    all.add(plan)
                                    store.savePlans(all)
                                    Planner.scheduleAll(this)
                                    toast("Planned: ${plan.title} at ${plan.timeText()}")
                                    render()
                                }
                            }
                        }
                    }
                }
                if (li < lengths.size) afterLength(lengths[li]) else askNumber("Length in minutes", 60) { afterLength(it.coerceIn(5, 480)) }
            }
        }
    }
}

// ====================================================================== Block
fun MainActivity.blockScreen(): View = page { col ->
    val c = this
    header(col, "Block")
    val full = fullEdition()
    val protection = protectionOk()

    // App limits.
    col.addView(Ui.section(c, "App limits"))
    val limits = Ui.card(c)
    val limitsLocked = lockNote("limits")
    val list = store.limits()
    if (list.isEmpty()) limits.addView(Ui.text(c, "Set a daily time limit on the apps that pull you in.", 14f, Ui.p.muted))
    for (l in list) {
        val used = if (demo()) Sample.usage(System.currentTimeMillis())[l.pkg] ?: 0L else UsageCache.msFor(l.pkg)
        val frac = (used.toFloat() / (l.minutes * 60_000f)).coerceIn(0f, 1f)
        limits.addView(Ui.line(c, l.label, "${Dates.duration(used)} of ${l.minutes} min", if (frac >= 1f) Ui.p.danger else Ui.p.text))
        limits.addView(Ui.splitBar(c, listOf(frac to (if (frac >= 1f) Ui.p.danger else Ui.p.accent), (1f - frac).coerceAtLeast(0.01f) to Ui.p.surface2)))
        val last = limits.getChildAt(limits.childCount - 2)
        last.setOnClickListener {
            if (limitsLocked != null) { toast("Limits are locked until ${Dates.until(store.lockUntil("limits"))}"); return@setOnClickListener }
            choose(l.label, listOf("Change limit", "Remove limit")) { i ->
                if (i == 0) askNumber("Daily limit for ${l.label} (minutes)", l.minutes) { m ->
                    val all = store.limits(); all.firstOrNull { it.pkg == l.pkg }?.minutes = m.coerceIn(1, 1440); store.saveLimits(all); render()
                } else {
                    store.saveLimits(store.limits().filter { it.pkg != l.pkg }); render()
                }
            }
        }
    }
    if (limitsLocked != null) limits.addView(Ui.text(c, "\uD83D\uDD12 $limitsLocked. Limits can't be changed or removed.", 13f, Ui.p.warn, true).apply { setPadding(0, Ui.dp(c, 8), 0, 0) })
    val addLimit = Ui.button(c, "+ Add an app limit", primary = false) {
        pickApp("Limit which app?") { pkg, label ->
            val options = listOf(15, 30, 45, 60, 90, 120)
            choose("Daily limit for $label", options.map { "$it minutes" }) { i ->
                val all = store.limits().filter { it.pkg != pkg }.toMutableList()
                all.add(AppLimit(pkg, label, options[i]))
                store.saveLimits(all)
                render()
            }
        }
    }
    Ui.add(limits, addLimit, 10)
    if (limitsLocked == null && list.isNotEmpty()) Ui.add(limits, Ui.button(c, "\uD83D\uDD12 Strict Mode: lock my limits") { commit("limits", "app limits") }, 8)
    col.addView(limits)

    // Reels & Shorts.
    col.addView(Ui.section(c, "Block Reels & Shorts"))
    val reels = Ui.card(c)
    if (!full) {
        reels.addView(Ui.text(c, "Available in ${Brand.APP} Full, which can recognise Reels and Shorts inside apps. " +
            "Lite can still limit or block these apps completely with App limits and focus sessions.", 14f, Ui.p.muted))
    } else {
        if (!protection) {
            reels.addView(Ui.text(c, "Turn on ${Brand.APP} protection so these work.", 14f, Ui.p.warn, true))
            Ui.add(reels, Ui.button(c, "Turn on protection") { openProtection() }, 8)
        }
        val reelsLocked = lockNote("protection")
        for ((key, name, desc) in listOf(
            Triple("block_ig_reels", "Instagram Reels", "Feed, Stories and messages still work"),
            Triple("block_yt_shorts", "YouTube Shorts", "Normal videos still work"),
            Triple("block_snap_spotlight", "Snapchat Spotlight", "Chats and Stories still work"),
            Triple("block_fb_reels", "Facebook Reels", "Feed and Messenger still work"))) {
            reels.addView(Ui.toggle(c, name, desc, store.bool(key, true), if (store.bool(key, true)) reelsLocked else null) { store.putBool(key, it) })
        }
        reels.addView(Ui.text(c, "Stopped today: ${store.count("reels")}", 13.5f, Ui.p.accent, true).apply { setPadding(0, Ui.dp(c, 6), 0, 0) })
    }
    col.addView(reels)

    // YouTube Study Mode.
    col.addView(Ui.section(c, "YouTube Study Mode"))
    val yt = Ui.card(c)
    if (!full) {
        yt.addView(Ui.text(c, "Available in ${Brand.APP} Full. In Lite, YouTube is blocked during focus sessions instead.", 14f, Ui.p.muted))
    } else {
        yt.addView(Ui.toggle(c, "Study channels only during focus", "Shorts and other channels are blocked while you focus.", store.bool("yt_study", false)) {
            store.putBool("yt_study", it); render()
        })
        val channels = store.set("yt_channels")
        if (channels.isEmpty()) yt.addView(Ui.text(c, "Add the channels you study with, exactly as their names appear on YouTube.", 13.5f, Ui.p.muted))
        for (ch in channels) {
            val l = Ui.line(c, "\u25B6 $ch", "Remove", Ui.p.danger)
            l.setOnClickListener { val s2 = store.set("yt_channels"); s2.remove(ch); store.putSet("yt_channels", s2); render() }
            yt.addView(l)
        }
        Ui.add(yt, Ui.button(c, "+ Add a study channel", primary = false) {
            askText("Study channel name", "e.g. Physics Wallah") { name -> val s2 = store.set("yt_channels"); s2.add(name); store.putSet("yt_channels", s2); render() }
        }, 8)
    }
    col.addView(yt)

    // Website blocker.
    col.addView(Ui.section(c, "Website blocker"))
    val web = Ui.card(c)
    val webLocked = lockNote("web")
    val webOn = store.bool("web_on", false) && WebShield.running
    web.addView(Ui.toggle(c, "Block websites", "Works in every browser and app on this phone.", webOn, if (webOn) webLocked else null) { on ->
        if (on) startWebShield() else { store.putBool("web_on", false); WebShield.stop(c) }
        main.postDelayed({ render() }, 700L)
    })
    web.addView(Ui.toggle(c, "Adult websites", "Blocks known adult sites and addresses with adult words.", store.bool("web_adult", true),
        if (store.bool("web_adult", true)) webLocked else null) { store.putBool("web_adult", it) })
    val blocked = store.set("web_block")
    for (site in blocked) {
        val l = Ui.line(c, "\u26D4 $site", if (webLocked == null) "Remove" else "", Ui.p.danger)
        l.setOnClickListener { if (webLocked == null) { val s2 = store.set("web_block"); s2.remove(site); store.putSet("web_block", s2); render() } }
        web.addView(l)
    }
    Ui.add(web, Ui.button(c, "+ Block a website", primary = false) {
        askText("Website to block", "e.g. instagram.com") { site -> val s2 = store.set("web_block"); s2.add(Sites.clean(site)); store.putSet("web_block", s2); render() }
    }, 8)
    if (webLocked == null) Ui.add(web, Ui.button(c, "\uD83D\uDD12 Strict Blocking: commit once") {
        if (!webOn) toast("Turn the website blocker on first.") else commit("web", "website blocker")
    }, 8)
    web.addView(Ui.text(c, "Blocked visits today: ${store.count("sites")}. If a site still opens, set Private DNS to Automatic or Off in your phone's network settings.",
        12.5f, Ui.p.muted).apply { setPadding(0, Ui.dp(c, 6), 0, 0) })
    col.addView(web)

    // Browser Study Mode.
    col.addView(Ui.section(c, "Browser Study Mode"))
    val bs = Ui.card(c)
    bs.addView(Ui.toggle(c, "Study sites only during focus", "Social, video and sports sites are blocked in every browser while you focus.", store.bool("browser_study", false)) {
        store.putBool("browser_study", it)
        if (it && !(store.bool("web_on", false) && WebShield.running)) startWebShield()
        render()
    })
    val study = store.set("study_sites")
    for (site in study) {
        val l = Ui.line(c, "\u2705 $site", "Remove", Ui.p.danger)
        l.setOnClickListener { val s2 = store.set("study_sites"); s2.remove(site); store.putSet("study_sites", s2); render() }
        bs.addView(l)
    }
    Ui.add(bs, Ui.button(c, "+ Allow a study site", primary = false) {
        askText("Study website", "e.g. khanacademy.org") { site -> val s2 = store.set("study_sites"); s2.add(Sites.clean(site)); store.putSet("study_sites", s2); render() }
    }, 8)
    col.addView(bs)

    // Block protection.
    col.addView(Ui.section(c, "Block protection"))
    val prot = Ui.card(c)
    val protLocked = lockNote("protection")
    prot.addView(Ui.line(c, "Uninstall protection", if (adminOk()) "On" else "Off", if (adminOk()) Ui.p.good else Ui.p.warn))
    if (!adminOk()) Ui.add(prot, Ui.button(c, "Turn on uninstall protection", primary = false) { openAdmin() }, 6)
    if (full) {
        prot.addView(Ui.toggle(c, "Protect ${Brand.APP}'s settings", "While a lock runs, blocks the screens that would uninstall, stop or switch off ${Brand.APP}.",
            store.bool("tamper", true), if (store.bool("tamper", true)) protLocked else null) { store.putBool("tamper", it) })
        prot.addView(Ui.toggle(c, "Block split-screen & floating windows", "During focus, stops blocked apps from sneaking back in a split or floating window.",
            store.bool("block_windows", true), if (store.bool("block_windows", true)) protLocked else null) { store.putBool("block_windows", it) })
        if (!protection) Ui.add(prot, Ui.button(c, "Turn on ${Brand.APP} protection") { openProtection() }, 8)
    } else {
        prot.addView(Ui.text(c, "Settings and split-screen protection are part of ${Brand.APP} Full.", 13.5f, Ui.p.muted))
    }
    if (protLocked == null) Ui.add(prot, Ui.button(c, "\uD83D\uDD12 Lock my protection settings") { commit("protection", "protection settings") }, 8)
    else prot.addView(Ui.text(c, "\uD83D\uDD12 $protLocked", 13f, Ui.p.warn, true))
    col.addView(prot)
    col.addView(Ui.text(c, Brand.BYLINE, 12f, Ui.p.muted).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 16), 0, 0) })
}
