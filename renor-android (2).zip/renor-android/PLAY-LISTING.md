# Play Store listing: ReNor by Nor Gaxmer Builds

**App name (30):** ReNor: Screen Time & Focus

**Title concept:** ReNor: Screen Time & App Blocker | Focus Timer | Block Reels & Shorts | Digital Wellbeing
(Play limits the title to 30 characters; put the rest in the short and full descriptions.)

**Short description (80):** Block Reels & Shorts, limit apps and focus with a strict study timer.

**Full description:**
Kill phone addiction and stay focused with ReNor, the smart study timer and app blocker by Nor Gaxmer Builds.

Built for students preparing for exams and anyone stuck doomscrolling, ReNor helps you cut screen time and build real
digital discipline, with a goal of 25% less screen time in your first week.

• Focus Timer: Timer, Stopwatch and Pomodoro with custom focus and break lengths, calm focus sounds, and Strict Mode
  that can't be stopped early.
• Block Reels & Shorts: stop Instagram Reels, YouTube Shorts, Snapchat Spotlight and Facebook Reels while keeping the
  rest of each app.
• App Limits with Strict Mode: daily limits you can lock so you can't cheat.
• YouTube & Browser Study Mode: study channels and study sites only, while you focus.
• Website Blocker: block adult and distracting sites, with Strict Blocking: commit once, no turning back.
• Block Protection: uninstall and settings protection while you're committed, plus split-screen and floating-window blocking.
• Insights: daily and weekly screen time, productive vs distracted time, and where your time goes.
• Planner & Streaks: plan focus sessions for the week, repeat them, and keep your streak alive.

No account. No ads. Your data stays on your phone.

**Category:** Productivity · **Tags:** digital wellbeing, focus timer, app blocker, screen time

**Declarations you'll need in Play Console:** Accessibility API (explain each use above, with a short video),
VPN service (website blocking on device), Usage access (screen time), foreground service "special use" (focus timer and blocking).
