#!/usr/bin/env bash
# Builds ReNor on GitHub: both editions as installable files, plus the Play Store file once your key is saved.
set -euo pipefail
cd "$(dirname "$0")"
GRADLE_VERSION="$(tr -d '[:space:]' < gradle-version.txt)"
export JAVA_HOME="${JAVA_HOME_17_X64:-${JAVA_HOME:-}}"
GRADLE="$HOME/gradle-$GRADLE_VERSION/bin/gradle"
if [ ! -x "$GRADLE" ]; then
  curl -fsSL -o /tmp/gradle.zip "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip"
  unzip -q -o /tmp/gradle.zip -d "$HOME"
fi
mkdir -p ../out
"$GRADLE" assembleFullDebug assembleLiteDebug --stacktrace --no-daemon
cp app/build/outputs/apk/full/debug/app-full-debug.apk ../out/ReNor-Full.apk
cp app/build/outputs/apk/lite/debug/app-lite-debug.apk ../out/ReNor-Lite.apk
if [ -n "${KEY_B64:-}" ] && [ -n "${KEY_PASS:-}" ]; then
  KEYFILE="${RUNNER_TEMP:-/tmp}/upload.jks"
  echo "$KEY_B64" | base64 -d > "$KEYFILE"
  RELEASE_KEYSTORE="$KEYFILE" RELEASE_STORE_PASSWORD="$KEY_PASS" RELEASE_KEY_PASSWORD="$KEY_PASS" RELEASE_KEY_ALIAS=upload \
    "$GRADLE" bundleFullRelease --stacktrace --no-daemon
  cp app/build/outputs/bundle/fullRelease/app-full-release.aab ../out/ReNor-PlayStore.aab
  rm -f "$KEYFILE"
fi
echo "Done"
