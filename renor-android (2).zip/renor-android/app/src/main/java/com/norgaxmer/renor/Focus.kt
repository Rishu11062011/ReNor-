package com.norgaxmer.renor

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import org.json.JSONObject
import java.util.Random

/** The live focus session, saved after every change so it survives ReNor being closed or the phone restarting. */
class FocusState(
    var mode: String = "pomodoro",          // "timer", "stopwatch" or "pomodoro"
    var phase: String = "focus",            // "focus", "short" or "long"
    var running: Boolean = false,
    var paused: Boolean = false,
    var phaseStart: Long = 0L,
    var phaseLength: Long = 0L,             // 0 for the stopwatch
    var elapsedBeforePause: Long = 0L,
    var round: Int = 1,
    var rounds: Int = 4,
    var cyclesBeforeLong: Int = 4,
    var strict: Boolean = false,
    var tag: String = "Study",
    var planId: String = "",
    var sessionStart: Long = 0L,
    var focusDoneMs: Long = 0L
) {
    fun elapsed(now: Long = System.currentTimeMillis()): Long =
        if (!running) 0L else if (paused) elapsedBeforePause else elapsedBeforePause + (now - phaseStart)

    fun remaining(now: Long = System.currentTimeMillis()): Long = maxOf(0L, phaseLength - elapsed(now))

    fun focusMsSoFar(now: Long = System.currentTimeMillis()): Long = focusDoneMs + if (phase == "focus") elapsed(now) else 0L

    fun inFocus(): Boolean = running && !paused && phase == "focus"

    fun toJson(): String = JSONObject().put("mode", mode).put("phase", phase).put("running", running).put("paused", paused)
        .put("phaseStart", phaseStart).put("phaseLength", phaseLength).put("before", elapsedBeforePause).put("round", round)
        .put("rounds", rounds).put("cycles", cyclesBeforeLong).put("strict", strict).put("tag", tag).put("plan", planId)
        .put("sessionStart", sessionStart).put("focusDone", focusDoneMs).toString()

    companion object {
        fun from(json: String): FocusState {
            val o = try { JSONObject(json) } catch (e: Exception) { return FocusState() }
            return FocusState(o.optString("mode", "pomodoro"), o.optString("phase", "focus"), o.optBoolean("running"), o.optBoolean("paused"),
                o.optLong("phaseStart"), o.optLong("phaseLength"), o.optLong("before"), o.optInt("round", 1), o.optInt("rounds", 4),
                o.optInt("cycles", 4), o.optBoolean("strict"), o.optString("tag", "Study"), o.optString("plan"), o.optLong("sessionStart"),
                o.optLong("focusDone"))
        }
    }
}

/** Timer, Stopwatch and Pomodoro. All times come from your settings (focus, short break, long break, rounds). */
object FocusTimer {
    fun state(store: Store): FocusState = FocusState.from(store.str("focus_state", "{}"))
    private fun save(store: Store, s: FocusState) = store.putStr("focus_state", s.toJson())

    fun focusMin(store: Store) = store.int("focus_min", 25)
    fun shortMin(store: Store) = store.int("short_min", 5)
    fun longMin(store: Store) = store.int("long_min", 15)
    fun timerMin(store: Store) = store.int("timer_min", 50)
    fun rounds(store: Store) = store.int("rounds", 4)
    fun cycles(store: Store) = store.int("cycles_before_long", 4)

    /** Total planned length of a session, for strict locks and the planner. */
    fun plannedLength(store: Store, mode: String, minutesOverride: Int?): Long {
        return when (mode) {
            "timer" -> (minutesOverride ?: timerMin(store)) * 60_000L
            "pomodoro" -> {
                val r = rounds(store)
                val focus = (minutesOverride?.let { maxOf(1, it / r) } ?: focusMin(store)) * 60_000L
                var total = focus * r
                for (i in 1 until r) total += (if (i % cycles(store) == 0) longMin(store) else shortMin(store)) * 60_000L
                total
            }
            else -> 0L
        }
    }

    fun start(store: Store, mode: String, strict: Boolean, tag: String, planId: String = "", minutesOverride: Int? = null) {
        val now = System.currentTimeMillis()
        val rounds = rounds(store)
        val focusLen = when (mode) {
            "timer" -> (minutesOverride ?: timerMin(store)) * 60_000L
            "pomodoro" -> (minutesOverride?.let { maxOf(1, it / rounds) } ?: focusMin(store)) * 60_000L
            else -> 0L
        }
        val s = FocusState(mode = mode, phase = "focus", running = true, paused = false, phaseStart = now, phaseLength = focusLen,
            round = 1, rounds = if (mode == "pomodoro") rounds else 1, cyclesBeforeLong = cycles(store),
            strict = strict && mode != "stopwatch", tag = tag, planId = planId, sessionStart = now, focusDoneMs = 0L)
        store.putLong("pomodoro_focus_len", focusLen)
        save(store, s)
        if (s.strict) store.lock("focus", now + plannedLength(store, mode, minutesOverride) + 60_000L)
    }

    fun pause(store: Store): Boolean {
        val s = state(store)
        if (!s.running || s.paused || s.strict) return false
        s.elapsedBeforePause = s.elapsed()
        s.paused = true
        save(store, s)
        return true
    }

    fun resume(store: Store) {
        val s = state(store)
        if (!s.running || !s.paused) return
        s.paused = false
        s.phaseStart = System.currentTimeMillis()
        save(store, s)
    }

    /** Ends the session. Strict sessions can only end by finishing (or [force] at completion). */
    fun stop(store: Store, completed: Boolean, force: Boolean = false): Boolean {
        val s = state(store)
        if (!s.running) return false
        if (s.strict && !completed && !force) return false
        val now = System.currentTimeMillis()
        val focus = s.focusMsSoFar(now)
        if (focus >= 60_000L) store.addSession(SessionRecord(s.sessionStart, now, focus, s.mode, s.tag, completed, s.planId))
        if (s.planId.isNotEmpty() && completed) {
            val done = store.set("plans_done")
            done.add(s.planId + "@" + Dates.key(now))
            store.putSet("plans_done", done)
        }
        save(store, FocusState())
        store.putLong("lock_focus", 0L)
        return true
    }

    /** Skips the current break (never the focus phase of a strict session). */
    fun skip(store: Store) {
        val s = state(store)
        if (!s.running || s.phase == "focus") return
        nextPhase(store, s, System.currentTimeMillis())
    }

    /** Moves the session on when a phase ends. Returns what happened: "short", "long", "focus", "done" or null. */
    fun tick(store: Store, now: Long = System.currentTimeMillis()): String? {
        val s = state(store)
        if (!s.running || s.paused || s.mode == "stopwatch" || s.phaseLength <= 0L) return null
        if (s.elapsed(now) < s.phaseLength) return null
        return nextPhase(store, s, now)
    }

    private fun nextPhase(store: Store, s: FocusState, now: Long): String {
        if (s.phase == "focus") {
            s.focusDoneMs += minOf(s.elapsed(now), s.phaseLength)
            if (s.mode == "timer" || s.round >= s.rounds) {
                s.phase = "end"   // the focus time is already counted in focusDoneMs
                save(store, s)
                stop(store, completed = true, force = true)
                return "done"
            }
            val long = s.round % s.cyclesBeforeLong == 0
            s.phase = if (long) "long" else "short"
            s.phaseLength = (if (long) longMin(store) else shortMin(store)) * 60_000L
        } else {
            s.round += 1
            s.phase = "focus"
            s.phaseLength = store.long("pomodoro_focus_len", focusMin(store) * 60_000L)
        }
        s.phaseStart = now
        s.elapsedBeforePause = 0L
        s.paused = false
        save(store, s)
        return s.phase
    }
}

/**
 * Calm background sound, generated on the phone (no downloads): brown, pink and white noise, rain and ocean.
 * Steady noise is a popular way to mask distracting sounds while studying.
 */
object Soundscape {
    val KINDS = listOf("off" to "Off", "brown" to "Brown noise", "pink" to "Pink noise", "white" to "White noise", "rain" to "Rain", "ocean" to "Ocean waves")

    @Volatile private var running = false
    @Volatile var kind = "off"
    @Volatile var volume = 0.5f
    private var thread: Thread? = null

    fun play(newKind: String, newVolume: Float) {
        kind = newKind
        volume = newVolume.coerceIn(0f, 1f)
        if (newKind == "off") { stop(); return }
        if (running) return
        running = true
        thread = Thread { loop() }.apply { isDaemon = true; start() }
    }

    fun stop() { running = false }

    fun isPlaying(): Boolean = running

    private fun loop() {
        val rate = 22050
        val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, rate))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) {
            running = false
            return
        }
        track.play()
        val buf = ShortArray(2048)
        val rnd = Random()
        var brown = 0.0
        var b0 = 0.0; var b1 = 0.0; var b2 = 0.0; var b3 = 0.0; var b4 = 0.0; var b5 = 0.0; var b6 = 0.0
        var drop = 0.0
        var t = 0L
        var fade = 0.0
        while (running) {
            val k = kind
            for (i in buf.indices) {
                val white = rnd.nextDouble() * 2 - 1
                b0 = 0.99886 * b0 + white * 0.0555179; b1 = 0.99332 * b1 + white * 0.0750759; b2 = 0.96900 * b2 + white * 0.1538520
                b3 = 0.86650 * b3 + white * 0.3104856; b4 = 0.55000 * b4 + white * 0.5329522; b5 = -0.7616 * b5 - white * 0.0168980
                val pink = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11
                b6 = white * 0.115926
                brown = (brown + 0.02 * white) / 1.02
                val sample = when (k) {
                    "white" -> white * 0.25
                    "pink" -> pink * 0.8
                    "brown" -> brown * 3.2
                    "rain" -> {
                        if (rnd.nextDouble() < 0.0009) drop = 0.6 + rnd.nextDouble() * 0.4
                        drop *= 0.992
                        pink * 0.55 + white * drop * 0.35
                    }
                    "ocean" -> {
                        val wave = 0.55 + 0.45 * Math.sin(2 * Math.PI * t / (rate * 9.0))
                        brown * 3.0 * wave + pink * 0.15 * wave
                    }
                    else -> 0.0
                }
                if (fade < 1.0) fade += 1.0 / (rate * 2)    // two-second fade in
                buf[i] = (sample * volume * fade * 14000).toInt().coerceIn(-32767, 32767).toShort()
                t++
            }
            track.write(buf, 0, buf.size)
        }
        try { track.stop() } catch (e: Exception) { }
        track.release()
    }
}
