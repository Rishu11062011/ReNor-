package com.norgaxmer.renor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

/** A colour theme. Every theme keeps strong contrast between text and background. */
class Pal(
    val key: String, val name: String, val dark: Boolean,
    val bg: Int, val surface: Int, val surface2: Int, val line: Int,
    val text: Int, val muted: Int, val accent: Int, val onAccent: Int,
    val good: Int, val warn: Int, val danger: Int
)

object Ui {
    private fun c(hex: String) = Color.parseColor(hex)

    val THEMES = listOf(
        Pal("night", "Calm Night", true, c("#0E1420"), c("#161F2E"), c("#1F2A3D"), c("#2B3850"), c("#EAF0F7"), c("#9AA8BC"),
            c("#5EEAD4"), c("#062A26"), c("#34D399"), c("#FBBF24"), c("#F87171")),
        Pal("paper", "Paper", false, c("#F4F6F8"), c("#FFFFFF"), c("#E8EDF2"), c("#D3DAE3"), c("#111827"), c("#4B5563"),
            c("#0F766E"), c("#FFFFFF"), c("#047857"), c("#B45309"), c("#B91C1C")),
        Pal("forest", "Forest", true, c("#0D1A14"), c("#13251C"), c("#1B3227"), c("#284636"), c("#E8F5EC"), c("#9DBBA8"),
            c("#86EFAC"), c("#05210F"), c("#4ADE80"), c("#FCD34D"), c("#FCA5A5")),
        Pal("dusk", "Dusk", true, c("#15121F"), c("#1E1A2C"), c("#28233A"), c("#3A3350"), c("#F1EDFA"), c("#AFA6C6"),
            c("#C4B5FD"), c("#1C1240"), c("#6EE7B7"), c("#FCD34D"), c("#FDA4AF"))
    )

    var p: Pal = THEMES[0]

    fun load(store: Store) { p = THEMES.firstOrNull { it.key == store.str("theme", "night") } ?: THEMES[0] }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()
    fun dpf(c: Context, v: Float): Float = v * c.resources.displayMetrics.density

    fun shape(c: Context, fill: Int, radius: Int, stroke: Int? = null): GradientDrawable = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(c, radius).toFloat()
        if (stroke != null) setStroke(dp(c, 1), stroke)
    }

    fun text(c: Context, s: String, size: Float = 15f, color: Int = p.text, bold: Boolean = false): TextView = TextView(c).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setLineSpacing(0f, 1.15f)
    }

    fun title(c: Context, s: String): TextView = text(c, s, 26f, p.text, true)
    fun section(c: Context, s: String): TextView = text(c, s.uppercase(), 12.5f, p.muted, true).apply {
        letterSpacing = 0.08f
        setPadding(0, dp(c, 18), 0, dp(c, 8))
    }

    fun col(c: Context): LinearLayout = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
    fun row(c: Context): LinearLayout = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    fun card(c: Context): LinearLayout = col(c).apply {
        background = shape(c, p.surface, 18, p.line)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    }

    fun add(parent: LinearLayout, child: View, topMargin: Int = 10) {
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(parent.context, topMargin)
        parent.addView(child, lp)
    }

    fun button(c: Context, label: String, primary: Boolean = true, enabled: Boolean = true, onTap: () -> Unit): TextView = TextView(c).apply {
        text = label
        textSize = 15f
        gravity = Gravity.CENTER
        setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        setPadding(dp(c, 18), dp(c, 12), dp(c, 18), dp(c, 12))
        setTextColor(if (primary) p.onAccent else p.text)
        background = if (primary) shape(c, p.accent, 24) else shape(c, p.surface2, 24, p.line)
        isEnabled = enabled
        alpha = if (enabled) 1f else 0.4f
        setOnClickListener { if (isEnabled) onTap() }
    }

    fun chip(c: Context, label: String, selected: Boolean, onTap: () -> Unit): TextView = TextView(c).apply {
        text = label
        textSize = 14f
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        setTextColor(if (selected) p.onAccent else p.text)
        background = if (selected) shape(c, p.accent, 20) else shape(c, p.surface2, 20, p.line)
        setOnClickListener { onTap() }
    }

    /** A row of equal-width buttons or chips. */
    fun strip(c: Context, views: List<View>, gap: Int = 8): LinearLayout {
        val r = row(c)
        views.forEachIndexed { i, v ->
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = dp(c, gap)
            r.addView(v, lp)
        }
        return r
    }

    /** Title, explanation and a switch. Locked switches show why and can't be changed. */
    fun toggle(c: Context, title: String, desc: String, checked: Boolean, locked: String? = null, onChange: (Boolean) -> Unit): LinearLayout {
        val r = row(c)
        val texts = col(c)
        texts.addView(text(c, title, 15.5f, p.text, true))
        if (desc.isNotEmpty()) texts.addView(text(c, desc, 13f, p.muted))
        if (locked != null) texts.addView(text(c, "\uD83D\uDD12 $locked", 12.5f, p.warn, true))
        r.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val s = Switch(c)
        s.isChecked = checked
        s.isEnabled = locked == null
        s.setOnCheckedChangeListener { _, on -> onChange(on) }
        r.addView(s)
        r.setPadding(0, dp(c, 6), 0, dp(c, 6))
        return r
    }

    /** A label on the left and a value on the right. */
    fun line(c: Context, left: String, right: String, rightColor: Int = p.text): LinearLayout {
        val r = row(c)
        r.addView(text(c, left, 14.5f, p.text), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(text(c, right, 14.5f, rightColor, true))
        r.setPadding(0, dp(c, 5), 0, dp(c, 5))
        return r
    }

    /** A horizontal bar split into coloured parts, like productive / neutral / distracted. */
    fun splitBar(c: Context, parts: List<Pair<Float, Int>>): LinearLayout {
        val r = row(c)
        r.background = shape(c, p.surface2, 6)
        val total = parts.sumOf { it.first.toDouble() }.toFloat().takeIf { it > 0f } ?: 1f
        for ((value, color) in parts) {
            if (value <= 0f) continue
            val v = View(c)
            v.background = shape(c, color, 6)
            r.addView(v, LinearLayout.LayoutParams(0, dp(c, 12), value / total))
        }
        return r
    }

    /** A coloured dot with a label, for chart legends. */
    fun legend(c: Context, color: Int, label: String, value: String): LinearLayout {
        val r = row(c)
        val dot = View(c)
        dot.background = shape(c, color, 6)
        r.addView(dot, LinearLayout.LayoutParams(dp(c, 12), dp(c, 12)))
        val t = text(c, label, 14f, p.text)
        t.setPadding(dp(c, 8), 0, 0, 0)
        r.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(text(c, value, 14f, p.muted, true))
        r.setPadding(0, dp(c, 4), 0, dp(c, 4))
        return r
    }
}

/** A circular progress ring with big text in the middle (focus timer, daily goal). */
class RingView(c: Context) : View(c) {
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var big = ""
        set(v) { field = v; invalidate() }
    var small = ""
        set(v) { field = v; invalidate() }
    var color = Ui.p.accent
        set(v) { field = v; invalidate() }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onDraw(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        val stroke = size * 0.07f
        val r = RectF((width - size) / 2 + stroke, (height - size) / 2 + stroke, (width + size) / 2 - stroke, (height + size) / 2 - stroke)
        track.strokeWidth = stroke; track.color = Ui.p.surface2
        arc.strokeWidth = stroke; arc.color = color
        canvas.drawArc(r, 0f, 360f, false, track)
        if (progress > 0f) canvas.drawArc(r, -90f, 360f * progress, false, arc)
        bigPaint.color = Ui.p.text; bigPaint.textSize = size * 0.17f
        smallPaint.color = Ui.p.muted; smallPaint.textSize = size * 0.07f
        canvas.drawText(big, width / 2f, height / 2f + bigPaint.textSize * 0.25f, bigPaint)
        if (small.isNotEmpty()) canvas.drawText(small, width / 2f, height / 2f + bigPaint.textSize * 0.25f + smallPaint.textSize * 1.6f, smallPaint)
    }
}

/** One day's bar: productive, neutral and distracted minutes stacked. */
class Bar(val label: String, val productive: Float, val neutral: Float, val distracted: Float, val highlight: Boolean = false)

/** Stacked daily bars for the week. */
class BarChartView(c: Context, private val bars: List<Bar>, private val unit: String = "h") : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    override fun onDraw(canvas: Canvas) {
        if (bars.isEmpty()) return
        val bottomPad = Ui.dpf(context, 22f)
        val topPad = Ui.dpf(context, 16f)
        val chartH = height - bottomPad - topPad
        val maxV = bars.maxOf { it.productive + it.neutral + it.distracted }.takeIf { it > 0f } ?: 1f
        val slot = width.toFloat() / bars.size
        val barW = slot * 0.5f
        label.textSize = Ui.dpf(context, 11f)
        for ((i, b) in bars.withIndex()) {
            val x = slot * i + (slot - barW) / 2
            var y = topPad + chartH
            for ((v, color) in listOf(b.productive to Ui.p.good, b.neutral to Ui.p.muted, b.distracted to Ui.p.danger)) {
                if (v <= 0f) continue
                val h = chartH * (v / maxV)
                paint.color = color
                canvas.drawRoundRect(RectF(x, y - h, x + barW, y), Ui.dpf(context, 4f), Ui.dpf(context, 4f), paint)
                y -= h
            }
            label.color = if (b.highlight) Ui.p.accent else Ui.p.muted
            label.typeface = if (b.highlight) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            canvas.drawText(b.label, x + barW / 2, height - Ui.dpf(context, 6f), label)
            val total = b.productive + b.neutral + b.distracted
            if (total > 0f) {
                label.color = Ui.p.muted
                val text = if (unit == "h") String.format(java.util.Locale.US, "%.1f", total / 60f) else total.toInt().toString()
                canvas.drawText(text, x + barW / 2, y - Ui.dpf(context, 4f), label)
            }
        }
    }
}

/** A donut chart for category or tag breakdowns. */
class DonutView(c: Context, private val slices: List<Pair<Float, Int>>, private val center: String) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

    override fun onDraw(canvas: Canvas) {
        val size = minOf(width, height).toFloat()
        val stroke = size * 0.16f
        paint.strokeWidth = stroke
        val r = RectF((width - size) / 2 + stroke / 2, (height - size) / 2 + stroke / 2, (width + size) / 2 - stroke / 2, (height + size) / 2 - stroke / 2)
        val total = slices.sumOf { it.first.toDouble() }.toFloat()
        if (total <= 0f) {
            paint.color = Ui.p.surface2
            canvas.drawArc(r, 0f, 360f, false, paint)
        } else {
            var start = -90f
            for ((v, color) in slices) {
                val sweep = 360f * v / total
                paint.color = color
                canvas.drawArc(r, start, sweep - 1.5f, false, paint)
                start += sweep
            }
        }
        text.color = Ui.p.text
        text.textSize = size * 0.13f
        canvas.drawText(center, width / 2f, height / 2f + text.textSize * 0.35f, text)
    }
}
