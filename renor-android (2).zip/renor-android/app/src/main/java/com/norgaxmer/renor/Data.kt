package com.norgaxmer.renor

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.Random

object Brand {
    const val APP = "ReNor"
    const val STUDIO = "Nor Gaxmer Builds"
    const val BYLINE = "ReNor by Nor Gaxmer Builds"
    const val TAGLINE = "Kill phone addiction and stay focused with a smart study timer and app blocker."
}

/** A daily time limit on one app. */
class AppLimit(val pkg: String, val label: String, var minutes: Int)

/** A planned focus session: one-off on [date], or repeating on [days] (Calendar.SUNDAY..SATURDAY). */
class Plan(
    val id: String,
    var title: String,
    var startMinute: Int,
    var minutes: Int,
    var days: Set<Int>,
    var date: String,
    var mode: String,
    var strict: Boolean,
    var autoStart: Boolean
) {
    fun occursOn(day: Calendar): Boolean =
        if (days.isNotEmpty()) day.get(Calendar.DAY_OF_WEEK) in days else date == Dates.key(day.timeInMillis)

    fun timeText(): String = Dates.clock(startMinute / 60, startMinute % 60)
}

/** A finished focus session, for insights and streaks. */
class SessionRecord(val start: Long, val end: Long, val focusMs: Long, val mode: String, val tag: String, val completed: Boolean, val planId: String)

object Dates {
    fun key(time: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(time))

    fun startOfDay(time: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = time
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun endOfDay(time: Long = System.currentTimeMillis()): Long = startOfDay(time) + 24L * 3600_000L

    fun clock(hour: Int, minute: Int): String =
        String.format(Locale.US, "%d:%02d %s", if (hour % 12 == 0) 12 else hour % 12, minute, if (hour < 12) "AM" else "PM")

    fun duration(ms: Long): String {
        val totalMin = (ms / 60_000L).toInt()
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "${m}m"
        }
    }

    fun countdown(ms: Long): String {
        val s = (maxOf(0L, ms) + 999) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    fun until(time: Long): String {
        val left = time - System.currentTimeMillis()
        if (left <= 0) return "now"
        val sameDay = key(time) == key(System.currentTimeMillis())
        val c = Calendar.getInstance()
        c.timeInMillis = time
        val clock = clock(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        return if (sameDay) "$clock today (${duration(left)} left)" else SimpleDateFormat("EEE d MMM", Locale.ENGLISH).format(Date(time)) + ", $clock"
    }

    val DAY_NAMES = listOf(Calendar.MONDAY to "Mon", Calendar.TUESDAY to "Tue", Calendar.WEDNESDAY to "Wed", Calendar.THURSDAY to "Thu",
        Calendar.FRIDAY to "Fri", Calendar.SATURDAY to "Sat", Calendar.SUNDAY to "Sun")
}

/** Everything ReNor remembers, in the app's private storage on this phone. */
class Store(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("renor", Context.MODE_PRIVATE)

    fun str(k: String, d: String = ""): String = p.getString(k, d) ?: d
    fun putStr(k: String, v: String) { p.edit().putString(k, v).apply() }
    fun int(k: String, d: Int): Int = p.getInt(k, d)
    fun putInt(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    fun long(k: String, d: Long = 0L): Long = p.getLong(k, d)
    fun putLong(k: String, v: Long) { p.edit().putLong(k, v).apply() }
    fun bool(k: String, d: Boolean): Boolean = p.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
    fun clearAll() { p.edit().clear().apply() }

    // ---------------------------------------------------------------- sets and maps
    fun set(k: String): MutableSet<String> {
        val arr = try { JSONArray(str(k, "[]")) } catch (e: Exception) { JSONArray() }
        val out = LinkedHashSet<String>()
        for (i in 0 until arr.length()) arr.optString(i).takeIf { it.isNotEmpty() }?.let { out.add(it) }
        return out
    }
    fun putSet(k: String, v: Set<String>) { putStr(k, JSONArray(v.toList()).toString()) }

    fun map(k: String): MutableMap<String, String> {
        val obj = try { JSONObject(str(k, "{}")) } catch (e: Exception) { JSONObject() }
        val out = LinkedHashMap<String, String>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            out[key] = obj.optString(key)
        }
        return out
    }
    fun putMap(k: String, v: Map<String, String>) {
        val obj = JSONObject()
        v.forEach { (key, value) -> obj.put(key, value) }
        putStr(k, obj.toString())
    }

    // ---------------------------------------------------------------- app limits
    fun limits(): MutableList<AppLimit> {
        val arr = try { JSONArray(str("limits", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<AppLimit>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(AppLimit(o.optString("pkg"), o.optString("label"), o.optInt("minutes", 30)))
        }
        return out
    }
    fun saveLimits(list: List<AppLimit>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("pkg", it.pkg).put("label", it.label).put("minutes", it.minutes)) }
        putStr("limits", arr.toString())
    }

    // ---------------------------------------------------------------- plans
    fun plans(): MutableList<Plan> {
        val arr = try { JSONArray(str("plans", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<Plan>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val days = HashSet<Int>()
            val d = o.optJSONArray("days") ?: JSONArray()
            for (j in 0 until d.length()) days.add(d.optInt(j))
            out.add(Plan(o.optString("id"), o.optString("title"), o.optInt("start"), o.optInt("minutes", 50), days, o.optString("date"),
                o.optString("mode", "pomodoro"), o.optBoolean("strict", false), o.optBoolean("auto", false)))
        }
        return out
    }
    fun savePlans(list: List<Plan>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().put("id", p.id).put("title", p.title).put("start", p.startMinute).put("minutes", p.minutes)
                .put("days", JSONArray(p.days.toList())).put("date", p.date).put("mode", p.mode).put("strict", p.strict).put("auto", p.autoStart))
        }
        putStr("plans", arr.toString())
    }

    // ---------------------------------------------------------------- focus history
    fun sessions(): MutableList<SessionRecord> {
        val arr = try { JSONArray(str("sessions", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<SessionRecord>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(SessionRecord(o.optLong("start"), o.optLong("end"), o.optLong("focus"), o.optString("mode"), o.optString("tag", "Study"),
                o.optBoolean("done", false), o.optString("plan")))
        }
        return out
    }
    fun addSession(r: SessionRecord) {
        val list = sessions()
        list.add(r)
        val keep = list.takeLast(600)
        val arr = JSONArray()
        keep.forEach {
            arr.put(JSONObject().put("start", it.start).put("end", it.end).put("focus", it.focusMs).put("mode", it.mode).put("tag", it.tag)
                .put("done", it.completed).put("plan", it.planId))
        }
        putStr("sessions", arr.toString())
        if (r.completed && r.focusMs >= 10 * 60_000L) {
            val days = set("streak_days")
            days.add(Dates.key(r.end))
            putSet("streak_days", days)
        }
    }

    // ---------------------------------------------------------------- strict locks ("commit once, no turning back")
    fun lockUntil(kind: String): Long = long("lock_$kind")
    fun isLocked(kind: String): Boolean = lockUntil(kind) > System.currentTimeMillis()
    fun lock(kind: String, until: Long) { if (until > lockUntil(kind)) putLong("lock_$kind", until) }
    fun anyLock(): Boolean = listOf("limits", "web", "focus", "protection").any { isLocked(it) }

    // ---------------------------------------------------------------- streaks and milestones
    fun streak(): Int {
        val days = set("streak_days")
        val c = Calendar.getInstance()
        if (!days.contains(Dates.key(c.timeInMillis))) c.add(Calendar.DAY_OF_YEAR, -1)
        var n = 0
        while (days.contains(Dates.key(c.timeInMillis))) {
            n++
            c.add(Calendar.DAY_OF_YEAR, -1)
        }
        return n
    }

    fun totalFocusMs(): Long = sessions().sumOf { it.focusMs }

    /** Reels/Shorts blocked today, counted by the Full edition. */
    fun bump(counter: String) {
        val k = "count_${counter}_" + Dates.key(System.currentTimeMillis())
        putInt(k, int(k, 0) + 1)
    }
    fun count(counter: String, day: Long = System.currentTimeMillis()): Int = int("count_${counter}_" + Dates.key(day), 0)
}

object Milestones {
    private val HOURS = listOf(1, 5, 10, 25, 50, 100, 250, 500, 1000)

    /** (reached, next) in focus hours. */
    fun of(totalMs: Long): Pair<Int, Int> {
        val hours = (totalMs / 3600_000L).toInt()
        val reached = HOURS.lastOrNull { it <= hours } ?: 0
        val next = HOURS.firstOrNull { it > hours } ?: (hours + 100)
        return Pair(reached, next)
    }
}

/** Realistic sample numbers, so every chart works before Usage access is granted (clearly labelled in the app). */
object Sample {
    val APPS = listOf(
        Triple("com.instagram.android", "Instagram", 52), Triple("com.google.android.youtube", "YouTube", 47),
        Triple("com.whatsapp", "WhatsApp", 38), Triple("com.android.chrome", "Chrome", 26),
        Triple("com.snapchat.android", "Snapchat", 18), Triple("com.google.android.apps.classroom", "Classroom", 22),
        Triple("com.google.android.apps.docs.editors.docs", "Docs", 16), Triple("com.duolingo", "Duolingo", 9)
    )

    fun usage(day: Long): Map<String, Long> {
        val rnd = Random(Dates.startOfDay(day))
        val daysAgo = ((Dates.startOfDay() - Dates.startOfDay(day)) / (24L * 3600_000L)).toInt()
        val improvement = 1.0 - minOf(daysAgo, 13) * -0.02   // older days were a little worse
        val out = LinkedHashMap<String, Long>()
        for ((pkg, _, base) in APPS) {
            val minutes = (base * improvement * (0.7 + rnd.nextDouble() * 0.6)).toLong()
            out[pkg] = minutes * 60_000L
        }
        if (Dates.startOfDay(day) == Dates.startOfDay()) {
            val fraction = (System.currentTimeMillis() - Dates.startOfDay()).toDouble() / (24 * 3600_000.0)
            for (k in out.keys.toList()) out[k] = (out[k]!! * maxOf(0.15, fraction)).toLong()
        }
        return out
    }

    fun label(pkg: String): String = APPS.firstOrNull { it.first == pkg }?.second ?: pkg

    fun sessions(): List<SessionRecord> {
        val out = ArrayList<SessionRecord>()
        val tags = listOf("Study", "Study", "Work", "Reading", "Coding")
        for (d in 0 until 7) {
            val day = Dates.startOfDay() - d * 24L * 3600_000L
            val rnd = Random(day + 7)
            repeat(1 + rnd.nextInt(3)) { i ->
                val start = day + (9 + i * 3) * 3600_000L
                val focus = (25 + rnd.nextInt(35)) * 60_000L
                out.add(SessionRecord(start, start + focus, focus, "pomodoro", tags[rnd.nextInt(tags.size)], true, ""))
            }
        }
        return out
    }
}
