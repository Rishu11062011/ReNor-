package com.norgaxmer.renor

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.window.OnBackInvokedDispatcher

/** Shown over a blocked app. Going back always leads to the home screen, never into the blocked app. */
class BlockActivity : Activity() {

    private val lines = listOf(
        "Every time you close it, the habit gets weaker.",
        "Future you is going to be glad you stopped here.",
        "Small wins, repeated, become discipline.",
        "Your focus is worth more than the next scroll.",
        "You set this up because you wanted more for yourself."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        Ui.load(store)
        window.statusBarColor = Ui.p.bg
        window.navigationBarColor = Ui.p.bg
        setContentView(build(store, intent))
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT) { goHome() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        setContentView(build(Store(this), intent))
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }

    private fun build(store: Store, i: Intent): View {
        val pkg = i.getStringExtra("pkg").orEmpty()
        val title = i.getStringExtra("title").orEmpty().ifEmpty { "Blocked by ${Brand.APP}" }
        val reason = i.getStringExtra("reason").orEmpty()
        val until = i.getLongExtra("until", 0L)
        val c = this
        val root = Ui.col(c).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Ui.p.bg)
            setPadding(Ui.dp(c, 28), Ui.dp(c, 48), Ui.dp(c, 28), Ui.dp(c, 32))
        }
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 35) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(Ui.dp(c, 28), Ui.dp(c, 48) + bars.top, Ui.dp(c, 28), Ui.dp(c, 32) + bars.bottom)
            }
            insets
        }
        root.addView(Ui.text(c, "\uD83D\uDEE1\uFE0F", 54f).apply { gravity = Gravity.CENTER })
        root.addView(Ui.text(c, title, 26f, Ui.p.text, true).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 12), 0, 0) })
        if (pkg.isNotEmpty()) root.addView(Ui.text(c, Usage.label(c, pkg), 16f, Ui.p.accent, true).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 6), 0, 0) })
        if (reason.isNotEmpty()) root.addView(Ui.text(c, reason, 16f, Ui.p.muted).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 14), 0, 0) })
        if (until > System.currentTimeMillis()) {
            root.addView(Ui.text(c, "Unlocks at ${Dates.until(until)}", 15f, Ui.p.warn, true).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 14), 0, 0) })
        }
        val card = Ui.card(c)
        card.addView(Ui.text(c, lines[(System.currentTimeMillis() / 60_000L % lines.size).toInt()], 16f, Ui.p.text).apply { gravity = Gravity.CENTER })
        val streak = store.streak()
        if (streak > 0) card.addView(Ui.text(c, "\uD83D\uDD25 $streak-day focus streak. Keep it alive.", 14f, Ui.p.good, true).apply { gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 8), 0, 0) })
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(c, 28)
        root.addView(card, lp)
        val home = Ui.button(c, "Back to home screen") { goHome() }
        val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp2.topMargin = Ui.dp(c, 24)
        root.addView(home, lp2)
        val open = Ui.button(c, "Open ${Brand.APP}", primary = false) {
            startActivity(Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            finish()
        }
        val lp3 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp3.topMargin = Ui.dp(c, 10)
        root.addView(open, lp3)
        val spacer = View(c)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(Ui.text(c, Brand.BYLINE, 12.5f, Ui.p.muted).apply { gravity = Gravity.CENTER })
        return root
    }
}
