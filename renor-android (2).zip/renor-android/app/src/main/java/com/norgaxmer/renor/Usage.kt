package com.norgaxmer.renor

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.view.inputmethod.InputMethodManager

/** Screen time and the app in front, from Android's own usage records (needs Usage access). */
object Usage {
    private const val RESUMED = 1      // UsageEvents.Event.ACTIVITY_RESUMED (MOVE_TO_FOREGROUND before Android 10)
    private const val PAUSED = 2       // UsageEvents.Event.ACTIVITY_PAUSED (MOVE_TO_BACKGROUND before Android 10)
    private const val SCREEN_OFF = 16  // UsageEvents.Event.SCREEN_NON_INTERACTIVE
    private const val LOCKED = 17      // UsageEvents.Event.KEYGUARD_SHOWN

    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** The app most recently brought to the front, or null if nothing changed in the last minute. */
    fun foreground(c: Context): String? {
        if (!hasAccess(c)) return null
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 60_000L, now)
        val e = UsageEvents.Event()
        var latest: String? = null
        var latestTime = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == RESUMED && e.timeStamp >= latestTime) {
                latest = e.packageName
                latestTime = e.timeStamp
            }
        }
        return latest
    }

    /** Time each app spent on screen between [start] and [end], in milliseconds. */
    fun between(c: Context, start: Long, end: Long): Map<String, Long> {
        if (!hasAccess(c)) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val events = usm.queryEvents(start, end)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        val ignored = ignored(c)
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            when (e.eventType) {
                RESUMED -> {
                    // Only one app is really in front: close whatever was open.
                    for ((p, t) in open) total[p] = (total[p] ?: 0L) + (e.timeStamp - t)
                    open.clear()
                    open[pkg] = e.timeStamp
                }
                PAUSED -> open.remove(pkg)?.let { t -> total[pkg] = (total[pkg] ?: 0L) + (e.timeStamp - t) }
                SCREEN_OFF, LOCKED -> {
                    for ((p, t) in open) total[p] = (total[p] ?: 0L) + (e.timeStamp - t)
                    open.clear()
                }
            }
        }
        val stop = minOf(end, System.currentTimeMillis())
        for ((p, t) in open) total[p] = (total[p] ?: 0L) + (stop - t)
        return total.filter { (p, ms) -> ms > 0 && p !in ignored }
    }

    fun today(c: Context): Map<String, Long> = between(c, Dates.startOfDay(), System.currentTimeMillis())

    /** Packages that aren't "screen time": ReNor, the home screen, the keyboard, system UI. */
    fun ignored(c: Context): Set<String> {
        val out = hashSetOf(c.packageName, "android", "com.android.systemui")
        launcher(c)?.let { out.add(it) }
        try {
            val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { out.add(it.packageName) }
        } catch (e: Exception) { }
        return out
    }

    fun launcher(c: Context): String? = try {
        c.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    } catch (e: Exception) {
        null
    }

    private val labels = HashMap<String, String>()

    fun label(c: Context, pkg: String): String {
        labels[pkg]?.let { return it }
        val name = try {
            c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            Sample.label(pkg)
        }
        labels[pkg] = name
        return name
    }

    /** Apps with a home-screen icon, sorted by name: (package, label). */
    fun apps(c: Context): List<Pair<String, String>> {
        val pm = c.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return list.map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.first != c.packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
    }

    // ---------------------------------------------------------------- productive or distracting
    val DISTRACTING = setOf(
        "com.instagram.android", "com.google.android.youtube", "com.facebook.katana", "com.facebook.lite", "com.snapchat.android",
        "com.twitter.android", "com.reddit.frontpage", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.instagram.barcelona",
        "in.mohalla.sharechat", "in.mohalla.video", "com.eterno.shortvideos", "com.verse.joshlive", "com.netflix.mediaclient",
        "in.startv.hotstar", "com.amazon.avod.thirdpartyclient", "com.pinterest", "com.tinder", "com.dream11.fantasy"
    )
    val PRODUCTIVE = setOf(
        "com.google.android.apps.classroom", "com.google.android.apps.docs.editors.docs", "com.google.android.apps.docs.editors.sheets",
        "com.google.android.apps.docs.editors.slides", "com.google.android.apps.docs", "notion.id", "com.byjus.thelearningapp",
        "com.unacademyapp", "xyz.penpencil.physicswala", "com.duolingo", "org.khanacademy.android", "org.coursera.android",
        "com.amazon.kindle", "com.microsoft.office.word", "com.microsoft.office.onenote", "com.microsoft.teams", "com.google.android.calendar",
        "com.google.android.keep", "com.todoist", "com.ticktick.task", "com.vedantu.app", "com.toppr.app", "com.adda247.app"
    )

    /** "productive", "distracting" or "neutral"; your own choice for an app always wins. */
    fun tag(c: Context, store: Store, pkg: String): String {
        store.map("app_tags")[pkg]?.let { return it }
        if (pkg in DISTRACTING) return "distracting"
        if (pkg in PRODUCTIVE) return "productive"
        return try {
            when (c.packageManager.getApplicationInfo(pkg, 0).category) {
                ApplicationInfo.CATEGORY_SOCIAL, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_GAME, ApplicationInfo.CATEGORY_NEWS -> "distracting"
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> "productive"
                else -> "neutral"
            }
        } catch (e: Exception) {
            if (Sample.APPS.any { it.first == pkg && it.second in setOf("Classroom", "Docs", "Duolingo") }) "productive" else "neutral"
        }
    }

    /** Category name for the breakdown chart. */
    fun category(c: Context, pkg: String): String {
        if (pkg in DISTRACTING) return if (pkg.contains("netflix") || pkg.contains("hotstar") || pkg.contains("avod")) "Video" else "Social"
        if (pkg in PRODUCTIVE) return "Study & work"
        return try {
            when (c.packageManager.getApplicationInfo(pkg, 0).category) {
                ApplicationInfo.CATEGORY_SOCIAL -> "Social"
                ApplicationInfo.CATEGORY_VIDEO -> "Video"
                ApplicationInfo.CATEGORY_GAME -> "Games"
                ApplicationInfo.CATEGORY_NEWS -> "News"
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Study & work"
                ApplicationInfo.CATEGORY_AUDIO -> "Music"
                else -> "Other"
            }
        } catch (e: Exception) {
            when (pkg) {
                "com.whatsapp" -> "Messaging"
                "com.android.chrome" -> "Browsing"
                else -> if (Sample.APPS.any { it.first == pkg }) "Study & work" else "Other"
            }
        }
    }
}
