package com.norgaxmer.renor

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/** Website lists: adult sites (always on unless you turn it off), common distractions, and your own lists. */
object Sites {
    val ADULT = setOf(
        "pornhub.com", "xvideos.com", "xnxx.com", "xhamster.com", "redtube.com", "youporn.com", "tube8.com", "spankbang.com",
        "brazzers.com", "onlyfans.com", "chaturbate.com", "stripchat.com", "livejasmin.com", "bongacams.com", "cam4.com",
        "eporner.com", "hqporner.com", "porntrex.com", "txxx.com", "motherless.com", "rule34.xxx", "e-hentai.org", "nhentai.net"
    )
    val ADULT_WORDS = listOf("porn", "xxx", "hentai", "xvideo", "sexcam", "nsfw")

    /** Blocked during Browser Study Mode, unless you allow them. */
    val DISTRACTING = setOf(
        "instagram.com", "facebook.com", "fb.com", "tiktok.com", "x.com", "twitter.com", "reddit.com", "snapchat.com", "netflix.com",
        "hotstar.com", "primevideo.com", "twitch.tv", "9gag.com", "pinterest.com", "threads.net", "sharechat.com", "mxplayer.in",
        "youtube.com", "m.youtube.com", "youtu.be", "cricbuzz.com", "espncricinfo.com", "dream11.com"
    )

    fun matches(domain: String, list: Collection<String>): Boolean = list.any { domain == it || domain.endsWith(".$it") }

    fun clean(input: String): String = input.trim().lowercase()
        .removePrefix("https://").removePrefix("http://").removePrefix("www.")
        .substringBefore("/").substringBefore(":")
}

/**
 * The website blocker. Android lets ReNor act as the phone's DNS (the service that turns website names into
 * addresses). Only DNS lookups pass through ReNor; all other traffic goes straight to the internet as normal.
 * Blocked names get "doesn't exist", so the site simply won't load.
 */
class WebShield : VpnService() {
    companion object {
        private const val ACTION_STOP = "com.norgaxmer.renor.STOP_WEB"
        private const val TUN_ADDRESS = "10.77.0.1"
        private const val FAKE_DNS = "10.77.0.2"
        @Volatile var running = false

        /** Starts the blocker if you've already allowed it (call VpnService.prepare from an activity first). */
        fun start(c: Context) {
            if (VpnService.prepare(c) != null) return
            try { c.startService(Intent(c, WebShield::class.java)) } catch (e: Exception) { }
        }

        fun stop(c: Context) {
            try { c.startService(Intent(c, WebShield::class.java).setAction(ACTION_STOP)) } catch (e: Exception) { }
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    private val pool = Executors.newFixedThreadPool(4)
    private lateinit var store: Store
    private var lists: Triple<Set<String>, Set<String>, Set<String>> = Triple(emptySet(), emptySet(), emptySet())
    private var listsAt = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        store = Store(this)
        if (intent?.action == ACTION_STOP) {
            if (!store.isLocked("web")) shutdown()
            return START_NOT_STICKY
        }
        if (tun == null) open()
        return START_STICKY
    }

    private fun open() {
        val builder = Builder()
            .setSession("${Brand.APP} website blocker")
            .addAddress(TUN_ADDRESS, 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .setMtu(1500)
        try { builder.addDisallowedApplication(packageName) } catch (e: Exception) { }
        val fd = try { builder.establish() } catch (e: Exception) { null } ?: return
        tun = fd
        running = true
        reader = Thread { readLoop(fd) }.apply { isDaemon = true; start() }
    }

    private fun shutdown() {
        running = false
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        stopSelf()
    }

    override fun onRevoke() {
        val wasLocked = store.isLocked("web")
        shutdown()
        if (wasLocked) GuardService.alert(this, 7400, "Website blocker was switched off",
            "Your Strict Blocking commitment is still running. Open ${Brand.APP} to switch the website blocker back on.")
    }

    override fun onDestroy() {
        running = false
        pool.shutdownNow()
        super.onDestroy()
    }

    private fun readLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val packet = ByteArray(32767)
        while (running) {
            val n = try { input.read(packet) } catch (e: Exception) { -1 }
            if (n <= 0) {
                if (!running) break
                try { Thread.sleep(20) } catch (e: InterruptedException) { break }
                continue
            }
            try { handle(packet.copyOf(n), output) } catch (e: Exception) { }
        }
    }

    // ---------------------------------------------------------------- deciding
    private fun currentLists(): Triple<Set<String>, Set<String>, Set<String>> {
        val now = System.currentTimeMillis()
        if (now - listsAt > 10_000L) {
            lists = Triple(store.set("web_block"), store.set("web_allow"), store.set("study_sites"))
            listsAt = now
        }
        return lists
    }

    fun blocked(domain: String): Boolean {
        val d = domain.lowercase().trimEnd('.')
        val (block, allow, study) = currentLists()
        if (Sites.matches(d, allow) || Sites.matches(d, study)) return false
        if (store.bool("web_adult", true) && (Sites.matches(d, Sites.ADULT) || Sites.ADULT_WORDS.any { d.contains(it) })) return true
        if (Sites.matches(d, block)) return true
        val focus = FocusTimer.state(store)
        if (store.bool("browser_study", false) && focus.running && focus.phase == "focus" && Sites.matches(d, Sites.DISTRACTING)) return true
        return false
    }

    // ---------------------------------------------------------------- DNS packets
    private fun handle(packet: ByteArray, output: FileOutputStream) {
        if (packet.size < 28) return
        if (((packet[0].toInt() shr 4) and 0xF) != 4) return            // IPv4 only
        val ihl = (packet[0].toInt() and 0xF) * 4
        if ((packet[9].toInt() and 0xFF) != 17 || packet.size < ihl + 8) return   // UDP only
        val dstPort = ((packet[ihl + 2].toInt() and 0xFF) shl 8) or (packet[ihl + 3].toInt() and 0xFF)
        if (dstPort != 53) return
        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl + 1].toInt() and 0xFF)
        val srcIp = packet.copyOfRange(12, 16)
        val dstIp = packet.copyOfRange(16, 20)
        val dns = packet.copyOfRange(ihl + 8, packet.size)
        val name = questionName(dns) ?: return
        if (blocked(name)) {
            if (store.bool("web_count", true)) store.bump("sites")
            write(output, udpPacket(dstIp, srcIp, 53, srcPort, notFound(dns) ?: return))
            return
        }
        pool.execute {
            val answer = forward(dns) ?: return@execute
            write(output, udpPacket(dstIp, srcIp, 53, srcPort, answer))
        }
    }

    private fun questionName(dns: ByteArray): String? {
        if (dns.size < 17) return null
        var i = 12
        val sb = StringBuilder()
        while (i < dns.size) {
            val len = dns[i].toInt() and 0xFF
            if (len == 0) break
            if (len >= 0xC0 || i + 1 + len > dns.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(dns, i + 1, len, Charsets.US_ASCII))
            i += len + 1
        }
        return if (sb.isEmpty()) null else sb.toString().lowercase()
    }

    /** A "no such website" answer to the question in [query]. */
    private fun notFound(query: ByteArray): ByteArray? {
        var i = 12
        while (i < query.size && (query[i].toInt() and 0xFF) != 0) i += (query[i].toInt() and 0xFF) + 1
        val end = i + 1 + 4                                                // name end + type + class
        if (end > query.size) return null
        val r = query.copyOfRange(0, end)
        r[2] = (0x80 or (query[2].toInt() and 0x79)).toByte()            // a response, same opcode and "recursion desired"
        r[3] = 0x83.toByte()                                              // recursion available, NXDOMAIN
        r[4] = 0; r[5] = 1                                                // one question
        for (k in 6..11) r[k] = 0                                         // no answers or extra records
        return r
    }

    /** Asks a real DNS server (outside the blocker) and returns its answer. */
    private fun forward(query: ByteArray): ByteArray? {
        val upstreams = listOf(store.str("dns_server", "1.1.1.1"), "8.8.8.8")
        for (server in upstreams.distinct()) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                protect(socket)
                socket.soTimeout = 4000
                socket.send(DatagramPacket(query, query.size, InetAddress.getByName(server), 53))
                val buf = ByteArray(4096)
                val reply = DatagramPacket(buf, buf.size)
                socket.receive(reply)
                return buf.copyOf(reply.length)
            } catch (e: Exception) {
                // try the next server
            } finally {
                socket?.close()
            }
        }
        return null
    }

    private fun udpPacket(src: ByteArray, dst: ByteArray, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40                                                       // don't fragment
        p[8] = 64                                                         // time to live
        p[9] = 17                                                         // UDP
        System.arraycopy(src, 0, p, 12, 4)
        System.arraycopy(dst, 0, p, 16, 4)
        var sum = 0
        for (k in 0 until 20 step 2) sum += ((p[k].toInt() and 0xFF) shl 8) or (p[k + 1].toInt() and 0xFF)
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val checksum = sum.inv() and 0xFFFF
        p[10] = (checksum shr 8).toByte(); p[11] = checksum.toByte()
        p[20] = (srcPort shr 8).toByte(); p[21] = srcPort.toByte()
        p[22] = (dstPort shr 8).toByte(); p[23] = dstPort.toByte()
        val udpLen = 8 + payload.size
        p[24] = (udpLen shr 8).toByte(); p[25] = udpLen.toByte()
        // UDP checksum 0 = "not used", which IPv4 allows.
        System.arraycopy(payload, 0, p, 28, payload.size)
        return p
    }

    private fun write(output: FileOutputStream, packet: ByteArray) {
        synchronized(output) {
            try { output.write(packet) } catch (e: Exception) { }
        }
    }
}
