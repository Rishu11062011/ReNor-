package com.norgaxmer.renor

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Toast

/**
 * ReNor protection (Full edition). Recognises Reels and Shorts screens, keeps YouTube to your study channels during
 * focus, and protects your commitments from being undone. It only looks at screen structure in these apps and in
 * system settings; nothing is stored or sent anywhere.
 */
class ReNorAccessibility : AccessibilityService() {
    companion object {
        private const val YT = "com.google.android.youtube"
        private val SETTINGS = setOf(
            "com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller", "com.miui.securitycenter",
            "com.coloros.safecenter", "com.samsung.android.lool", "com.android.vpndialogs"
        )
        private val DANGER = listOf(
            "uninstall", "force stop", "deactivate", "clear storage", "clear data", "turn off", "disable", "disconnect", "forget vpn", "stop"
        )
    }

    private lateinit var store: Store
    private var lastAction = 0L
    private var lastScan = 0L
    private var ytWatchingSince = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = Store(this)
        Rules.protectionOn = true
        GuardService.start(this)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Rules.protectionOn = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (!::store.isInitialized) store = Store(this)
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val now = System.currentTimeMillis()
        if (now - lastAction < 800L) return

        // 1. Whole-app blocking, faster than the guard's check.
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != "com.android.systemui") {
            if (pkg != UsageCache.current) {
                UsageCache.current = pkg
                UsageCache.currentSince = now
            }
            val v = Rules.check(this, store, pkg)
            if (v.block) { block(pkg, v); return }
        }

        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && now - lastScan < 400L) return
        lastScan = now
        val root = rootInActiveWindow ?: return

        // 2. Protecting your commitments from being undone in system settings.
        if (store.anyLock() && store.bool("tamper", true) && (pkg in SETTINGS || pkg.contains("settings")) && tamper(root)) {
            act(GLOBAL_ACTION_HOME, "${Brand.APP} is protecting your commitment until it ends.")
            return
        }

        // 3. Reels & Shorts.
        val reel = reels(pkg, root)
        if (reel != null) {
            store.bump("reels")
            act(GLOBAL_ACTION_BACK, "$reel blocked by ${Brand.APP}")
            return
        }

        // 4. YouTube Study Mode.
        if (pkg == YT && ytStudyBlocks(root, now)) {
            act(GLOBAL_ACTION_BACK, "During focus, YouTube plays only your study channels.")
            return
        }

        // 5. Split-screen and floating windows during focus.
        if (store.bool("block_windows", true)) windowsCheck()
    }

    private fun act(action: Int, message: String) {
        lastAction = System.currentTimeMillis()
        performGlobalAction(action)
        try { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() } catch (e: Exception) { }
    }

    private fun block(pkg: String, v: Verdict) {
        lastAction = System.currentTimeMillis()
        val i = Intent(this, BlockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("pkg", pkg).putExtra("title", v.title).putExtra("reason", v.reason).putExtra("until", v.until)
        try { startActivity(i) } catch (e: Exception) { performGlobalAction(GLOBAL_ACTION_HOME) }
    }

    // ---------------------------------------------------------------- recognising screens
    private fun id(n: AccessibilityNodeInfo, part: String): Boolean = n.viewIdResourceName?.contains(part, ignoreCase = true) == true
    private fun desc(n: AccessibilityNodeInfo): String = n.contentDescription?.toString().orEmpty()
    private fun txt(n: AccessibilityNodeInfo): String = n.text?.toString().orEmpty()

    private fun find(root: AccessibilityNodeInfo, test: (AccessibilityNodeInfo) -> Boolean): Boolean {
        val stack = java.util.ArrayDeque<AccessibilityNodeInfo>()
        stack.push(root)
        var seen = 0
        while (stack.isNotEmpty() && seen < 1500) {
            val n = stack.pop()
            seen++
            if (test(n)) return true
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.push(it) }
        }
        return false
    }

    private fun texts(root: AccessibilityNodeInfo, limit: Int): List<String> {
        val out = ArrayList<String>()
        val stack = java.util.ArrayDeque<AccessibilityNodeInfo>()
        stack.push(root)
        var seen = 0
        while (stack.isNotEmpty() && seen < 1500 && out.size < limit) {
            val n = stack.pop()
            seen++
            txt(n).takeIf { it.isNotBlank() }?.let { out.add(it) }
            desc(n).takeIf { it.isNotBlank() }?.let { out.add(it) }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.push(it) }
        }
        return out
    }

    private fun selectedTab(n: AccessibilityNodeInfo, name: String): Boolean =
        n.isSelected && (desc(n).equals(name, ignoreCase = true) || txt(n).equals(name, ignoreCase = true))

    /** The name of the short-video feed on screen, or null. */
    private fun reels(pkg: String, root: AccessibilityNodeInfo): String? = when (pkg) {
        "com.instagram.android" ->
            if (store.bool("block_ig_reels", true) && find(root) { id(it, "clips_viewer") || id(it, "clips_video_container") || selectedTab(it, "Reels") })
                "Instagram Reels" else null
        YT ->
            if (store.bool("block_yt_shorts", true) && find(root) { id(it, "reel_player") || id(it, "reel_recycler") || id(it, "shorts_player") || selectedTab(it, "Shorts") })
                "YouTube Shorts" else null
        "com.snapchat.android" ->
            if (store.bool("block_snap_spotlight", true) && find(root) { selectedTab(it, "Spotlight") || id(it, "spotlight_feed") })
                "Snapchat Spotlight" else null
        "com.facebook.katana", "com.facebook.lite" ->
            if (store.bool("block_fb_reels", true) && find(root) { id(it, "reels_viewer") || selectedTab(it, "Reels") || selectedTab(it, "Video, tab") })
                "Facebook Reels" else null
        else -> null
    }

    /** During focus: is a video from outside your study channels playing? Waits a moment for the page to load. */
    private fun ytStudyBlocks(root: AccessibilityNodeInfo, now: Long): Boolean {
        if (!store.bool("yt_study", false)) return false
        val focus = FocusTimer.state(store)
        if (!(focus.running && !focus.paused && focus.phase == "focus")) return false
        val channels = store.set("yt_channels")
        if (channels.isEmpty()) return false
        val watching = find(root) { id(it, "watch_player") || id(it, "player_view") || id(it, "watch_while") }
        if (!watching) { ytWatchingSince = 0L; return false }
        val all = texts(root, 500)
        if (channels.any { ch -> all.any { it.contains(ch, ignoreCase = true) } }) { ytWatchingSince = 0L; return false }
        if (ytWatchingSince == 0L) { ytWatchingSince = now; return false }
        return now - ytWatchingSince > 2500L
    }

    /** A settings screen about ReNor offering to uninstall, stop or switch it off. */
    private fun tamper(root: AccessibilityNodeInfo): Boolean {
        val all = texts(root, 300).map { it.lowercase() }
        if (all.none { it.contains(Brand.APP.lowercase()) }) return false
        return all.any { t -> DANGER.any { d -> t == d || t.startsWith(d) } }
    }

    private fun windowsCheck() {
        val focus = FocusTimer.state(store)
        if (!(focus.running && !focus.paused && focus.phase == "focus")) return
        val apps = try { windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION } } catch (e: Exception) { return }
        val floating = apps.any { it.isInPictureInPictureMode }
        if (apps.size < 2 && !floating) return
        for (w in apps) {
            val pkg = w.root?.packageName?.toString() ?: continue
            if (pkg == packageName) continue
            val v = Rules.check(this, store, pkg)
            if (v.block) {
                if (apps.size >= 2) performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
                block(pkg, v)
                return
            }
        }
    }
}
