# ReNor by Nor Gaxmer Builds

**Kill phone addiction and stay focused with a smart study timer and app blocker.**

ReNor helps students preparing for exams, and anyone fighting doomscrolling, cut screen time and build lasting digital
discipline. Everything runs on your phone: no account, no ads, no tracking.

## Two editions

| | ReNor Full | ReNor Lite |
|---|---|---|
| Focus timer: Timer, Stopwatch, Pomodoro, Strict Mode, soundscapes | ✅ | ✅ |
| App limits with Strict Mode | ✅ | ✅ |
| Website blocker, Strict Blocking, Browser Study Mode | ✅ | ✅ |
| Screen time insights, planner, streaks | ✅ | ✅ |
| Block Instagram Reels, YouTube Shorts, Snapchat Spotlight, Facebook Reels | ✅ | ❌ (block the whole app instead) |
| YouTube Study Mode (study channels only) | ✅ | ❌ |
| Uninstall & settings protection, block split-screen / floating windows | ✅ | ❌ |

Full uses Android's Accessibility service ("ReNor protection"). Play Protect treats Accessibility as high-risk, so it often
blocks installing Full from outside the Play Store and may label it harmful. Install **ReNor Lite** yourself, and get Full
through the Play Store (Play Console internal testing works within minutes, see PUBLISHING below). Lite uses no high-risk
permissions.

## Build it (GitHub, free)

1. Create a **new private repository** on GitHub, for example `ReNor` (README off, .gitignore and licence None).
2. **Add file > Upload files**: upload `renor-android.zip` and commit.
3. Make the workflow folder: **Add file > Create new file**, paste `.github/workflows/main.yml` as the name, type `x` as
   the content, and commit. (The build that starts now fails. That's expected.)
4. Open **.github > workflows**, tap **Add file > Upload files**, upload **main.yml** from this zip (it replaces the
   placeholder), and commit.
5. **Actions** tab: wait for the green tick, then download **ReNor-app**. It contains `ReNor-Full.apk` and `ReNor-Lite.apk`.

To update later, delete the old zip, upload the new one and wait for the green tick. The workflow file never changes.

## First run

1. Open ReNor > **Home > Finish setup** and allow: **Usage access**, **Notifications**, **Unrestricted battery**,
   **Alarms & reminders**, and on Lite **Display over other apps**.
2. Full edition: turn on **ReNor protection** (if it's greyed out: Settings > Apps > ReNor > ⋮ > Allow restricted settings).

## Where things are

- **Home**: today vs your goal, productive vs distracted time, weekly −25% target, streak, focus milestones, quick start.
- **Focus**: Timer / Stopwatch / Pomodoro, durations, Strict Mode, tags, focus sounds, apps allowed in Strict Mode.
- **Block**: app limits (+ Strict lock), Reels & Shorts, YouTube Study Mode, website blocker (+ Strict Blocking),
  Browser Study Mode, block protection.
- **Insights**: today or this week: stacked charts, category donut, focus tags, app re-tagging.
- **Plan**: week calendar, planned and repeating sessions, auto-start, done/missed, streak.
- **Settings** (gear on Home): permissions, goals, themes, sample data, about.

## How the engines connect (for developers)

- `Data.kt`: storage, models (limits, plans, sessions, locks), streaks, sample data.
- `Usage.kt`: screen time from Android's usage events; productive/distracting tags.
- `Focus.kt`: focus state machine and generated soundscapes.
- `Guard.kt`: `Rules` (the single blocking decision), `GuardService` (foreground service: timer, detection, block
  screen, alerts), `Planner` (alarms), receivers.
- `WebShield.kt`: on-device DNS filter (Android VpnService) for the website blocker and Browser Study Mode.
- `full/…/ReNorAccessibility.kt`: block screen, Reels & Shorts, YouTube Study Mode, uninstall/settings protection, split-screen/floating windows.
- `Ui.kt`, `MainActivity.kt`, `Screens*.kt`: themes, charts and screens.

Reels/Shorts and YouTube detection rely on how those apps label their screens, which they change from time to time;
update the patterns in `ReNorAccessibility.kt` if one stops working.
